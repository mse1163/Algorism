package com.ssafy.emp;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class EmpClient extends Thread {
	private List<Employee> emps = new ArrayList<>();
	private String ip;
	private int port;

	public EmpClient() {

	}

	public EmpClient(List<Employee> emps) {
		this.emps = emps;
		ip="localhost";
		port=6000;
	}

	@Override
	public void run() {
		try (Socket socket = new Socket(ip, port);
				ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());){
			for(Employee e : emps)
				oos.writeObject(e);
		} catch (IOException e) {
			return;
		}
	}
}
