package com.ssafy.emp;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;


public class EmpMgrImpl implements IEmpMgr{	
	
    /** 직원나 매니저의 정보를 저장하기 위한 리스트 */
	private List<Employee> emps = new ArrayList<Employee>();
	private static EmpMgrImpl mgr = new EmpMgrImpl();

	public  EmpMgrImpl() {
		load("emp.dat");
	}

	public static EmpMgrImpl getInstance() {
		return mgr;
	}
	
	
	/** 파일로 부터 자료 읽어서 메모리(ArrayList)에 저장하기*/
	public void load(String filename) {
		File  file=new File(filename);
		System.out.println(file);
		if (!file.exists()) return; 
		emps.clear();
		ObjectInputStream ois=null;
		Object ob=null;
		try{	
			ois=new ObjectInputStream(new FileInputStream(file));
			while(true){//마지막 EOF Exception발생
				ob=ois.readObject();
				emps.add((Employee)ob);
			}
		}catch(EOFException ee){System.out.println("읽기 완료");
		}catch(FileNotFoundException fe){
			System.out.println("파일이 존재하지 않습니다");
		}catch(IOException ioe){
			System.out.println(ioe);
		}catch(ClassNotFoundException ce){
			System.out.println("같은 클래스 타입이 아닙니다");
		}finally{
			if(ois !=null){
				try{
					ois.close();
				}catch(IOException oe){System.out.println("파일을 닫는데 실패했습니다");}
			}
		}
	}
  
	
	// filename에 객체를 쓰는 메서드
	public void save(String filename) {
		File file = new File(filename);

			try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file));){
				for(Employee e : emps)
				oos.writeObject(e);
				oos.flush();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		
	}
	// Employee를 저장하는 매서드
	public void add(Employee b) throws DuplicateException{
		for(Employee e : emps) {
			if(e.getEmpNo()==b.getEmpNo()) {
				throw new DuplicateException();
			}
		}
		emps.add(b);
	}
	
	public List<Employee>  search(){
    	return emps;
    }
	
	// 번호를 이용하여 검색된 직원을 리턴하는 메서드
	public Employee search(int num) throws RecordNotFoundException{
		for(Employee e : emps) {
			if(e.getEmpNo()==num) {
				return e;
			}
		}
		throw new RecordNotFoundException();
	}
	// 번호를 찾아 직원정보를 수정하는 메서드
	public void update(Employee b) throws RecordNotFoundException{
		boolean isOk = true;
		for(Employee e : emps) {
			if(e.getEmpNo()==b.getEmpNo()) {
				isOk=false;
				e.setDept(b.getDept());
				e.setPosition(b.getPosition());
				return;
			}
		}
		throw new RecordNotFoundException();
	}
	// 번호를 찾아 직원 정보를 삭제하는 메서드
	public void delete(int num) throws RecordNotFoundException{
		for(Employee e : emps) {
			if(e.getEmpNo()==num) {
				emps.remove(e);
				return;
			}
		}
		throw new RecordNotFoundException();
	}
	
}
