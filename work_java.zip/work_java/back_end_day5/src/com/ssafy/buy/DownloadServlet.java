package com.ssafy.buy;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DownloadServlet
 */
@WebServlet("/download")
public class DownloadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fileName = request.getParameter("file");
		
		// 다운로드를 위한 response 설정
		response.setContentType("application/octet-stream");	// 일반 텍스트가 아님
		// 다운로드될 파일의 이름
		response.setHeader("Content-Disposition", "attachment; filename="+fileName);
		// 스트림 연결(file input --> response output)
		// 로컬의 파일에 연결하는 스트림
		BufferedInputStream bis = new BufferedInputStream(new FileInputStream("c:\\Temp\\"+fileName));
		OutputStream output = response.getOutputStream();
		BufferedOutputStream bos = new BufferedOutputStream(output);
		
		byte[] buffer = new byte[100];
		int readed = -1;
		
		while( (readed = bis.read(buffer)) != -1) {
			bos.write(buffer, 0, readed);
		}
		// 정리 작업
		if(bis!=null) {
			bis.close();
		}
		if(bos!=null) {
			bos.close();
		}
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
	}

}
