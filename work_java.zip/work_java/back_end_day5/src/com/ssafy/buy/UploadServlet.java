package com.ssafy.buy;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class UploadServlet
 */
@WebServlet("/upload")
@MultipartConfig(
		fileSizeThreshold = 1024*1024*10,	// 메모리에 임시 저장하기 위한 최대 크기
		maxFileSize = 1024*1024*20,			// 단일 파일의 최대 크기
		maxRequestSize = 1024*1024*50,		// 모든 파일의 총 합
		location="c:\\Temp"
		)
public class UploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 일반적인 파라미터들은 이제까지 처럼....
		String desc = request.getParameter("desc");
		
		// 파일 관련 처리
		Part part = request.getPart("file");
		System.out.println(part.getSubmittedFileName()+" "+part.getSize());
		part.write(part.getSubmittedFileName());
		
		response.getWriter().append("업로드 완료"+part.getSubmittedFileName()+" , "+desc);
	}

}
