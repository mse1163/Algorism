

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InputServlet
 */
@WebServlet("/Input")
public class InputServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String name = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));
		String summary = request.getParameter("summary");
		
		
		StringBuilder html = new StringBuilder();
		html.append("<!DOCTYPE html><html><head></head><body>" + 
				"	<h1>상품 입력 확인</h1><table>" + 
				"	<tr><th>상&nbsp;품&nbsp;명:</th><td>"+name+"</td></tr>" + 
				"	<tr><th>상품가격:</th><td>"+price+"</td></tr>" + 
				"	<tr><th>상품설명:</th><td>"+summary+"</td></tr>" + 
				"	</table></body></html>");
		
		response.getWriter().append(html.toString());
	}

}
