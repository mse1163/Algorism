import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Solution4672 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {

			String W = br.readLine();

			N = W.length();

			char[] text = new char[N];
			for (int i = 0; i < N; i++) {
				text[i] = W.charAt(i);
			}

			Arrays.sort(text);

			// System.out.println(Arrays.toString(text));
			sel = new boolean[N];
			cnt = 0;
			powerset(text);

			sb.append("#").append(t).append(" ").append(cnt).append("\n");

		}
		bw.write(sb.toString());
		bw.flush();
		bw.close();

	}

	static int N, cnt;
	static boolean[] sel;

	static void powerset(char[] text) {
		List<Character> list = new ArrayList<>();
		List<Character> relist = new ArrayList<>();

		for (int k = 0; k < N; k++) {
			for (int i = 0; i < N; i++) {
				list = new ArrayList<>();
				relist = new ArrayList<>();
				for (int j = k; j < i + 1; j++) {
					 System.out.print(text[j] + " ");
					list.add(text[j]);
					relist.add(text[j]);
				}
				 System.out.println();
				if (!list.isEmpty()) {
					if (check(list, relist)) {
						cnt++;
					}
				}
			}
		}

	}

	static boolean check(List<Character> list, List<Character> relist) {
		Collections.reverse(relist);

		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).equals(relist.get(i))) {
				continue;
			} else {

				return false;

			}
		}

		return true;
	}

}
