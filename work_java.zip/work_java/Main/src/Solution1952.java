import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Solution1952 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {
			StringTokenizer token = new StringTokenizer(br.readLine());

			price = new int[4];
			for (int i = 0; i < 4; i++) {
				price[i] = Integer.parseInt(token.nextToken());
			}

			int[] mon = new int[14];

			token = new StringTokenizer(br.readLine());
			for (int i = 0; i < 12; i++) {
				mon[i] = Integer.parseInt(token.nextToken());
			}
			
			System.out.println(Arrays.toString(mon));
			
			
			min = 987654321;
			cal(mon);
			
			System.out.println("#"+t+" "+min);
		}
	}

	static int[] price;
	static int min;
	
	static void cal(int[] mon) {
		int[] month = new int[14];
		month = mon;
		min = Math.min(min, oneday(month));
		min = Math.min(min, one_month(month));
		min = Math.min(min, third_month(month));

		
	}

	static int oneday(int[] month) {
		// 1일 이용시 요금
		int sum = 0;
		for (int i = 0; i < 12; i++) {
			if (month[i] != 0) {
				month[i] *= price[0];
			}

			sum += month[i];
		}
		if(min<sum)
			return min;
		else
			return sum;
	}
	
	static int one_month(int[] month) {
		int sum = 0;
		for (int i = 0; i < 12; i++) {
			if (month[i] != 0 && month[i] > price[1]) {
				month[i] = price[1];
			}
			
			sum+= month[i];
		}
		
		if(min<sum)
			return min;
		else
			return sum;
	}
	
	static int third_month(int[] month) {
		int sum = 0;

		for (int i = 0; i < 14; i++) {
			if (month[i] != 0 && month[i + 1] != 0 && month[i + 2] != 0) {
				int third_sum = month[i] + month[i + 1] + month[i + 2];
				
				if (third_sum > price[2]) {
					sum+= price[2];
					i = i+3;
				}

			}
			
			else if (month[i] != 0 && month[i + 1] != 0 && month[i + 2] == 0) {
				int third_sum = month[i] + month[i + 1];
				
				if (third_sum > price[2]) {
					sum+= price[2];
					i = i+3;
				}

			}
			
			else if (month[i] != 0 && month[i + 1] == 0 && month[i + 2] == 0) {
				int third_sum = month[i];
				
				if (third_sum > price[2]) {
					sum+= price[2];
					i = i+3;
				}

			}
			sum+= month[i];
			
		}
		if(min>sum) {
			min = sum;
		}
		
		if(min<sum)
			return min;
		return min;
		
	}
}
