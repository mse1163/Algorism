import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class 수영장_재귀 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {
			StringTokenizer token = new StringTokenizer(br.readLine());

			int[] price = new int[4];
			for (int i = 0; i < 4; i++) {
				price[i] = Integer.parseInt(token.nextToken());
			}

			int[] plan = new int[12];

			token = new StringTokenizer(br.readLine());
			for (int i = 0; i < 12; i++) {
				plan[i] = Integer.parseInt(token.nextToken());
			}
			
			System.out.println(Arrays.toString(plan));
			ans=987654321;
			solve(price, plan, 0, 0);
			System.out.println(ans);
		}
	}
	
	// price, plan은 static으로 박아둬도 됨
	// month : 현재 처리하고자 하는 일
	// sum : 지금까지의 티켓 값 총합
	static int ans=0;
	static void solve(int[] price, int[] plan, int month, int sum) {
		if(month > 12) {
			return;
		}
		if(month == 12) {
			// 모든 원에 대해 티켓 배정 완료
			ans = Math.min(ans, sum);
			return;
		}
		
		// 해당 월을 1일권으로 처리하는 경우
		solve(price, plan, month+1, sum+plan[month]*price[0]);
		// 해당 월을  1개월권으로 처리하는 경우
		solve(price, plan, month+1, sum+price[1]);
		// 해당 월을 3개월권을 끊는 경우
		solve(price, plan, month+3, sum+price[2]);
		// 해당 월을 1년으로 끊는 경우
		solve(price, plan, month+12, sum+price[3]);
		
	}

}
