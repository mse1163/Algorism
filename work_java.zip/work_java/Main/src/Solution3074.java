import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Solution3074 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {
			StringTokenizer token = new StringTokenizer(br.readLine());
			N = Integer.parseInt(token.nextToken());
			M = Integer.parseInt(token.nextToken());	// 사람수
			
			time = new int[N];
			int max = -1;
			for(int i=0; i<N; i++) {
				time[i] = Integer.parseInt(br.readLine());
				if(max<time[i]) {
					max = time[i];
				}
			}
			
			long start = 0;
			long end = (long)max*M;
			int k = M;
			long result = lowerBinarySearch(start, end, k);
			
			sb.append("#").append(t).append(" ").append(result).append("\n");
		}
		bw.write(sb.toString());
		bw.flush();
		bw.close();
		
	}
	
	static int N, M;
	static int[] time;
	static long lowerBinarySearch(long start, long end, long k) {
		
		while(start<=end) {
			
			long mid = (start + end) /2;
			long sum=0;
			for(int i=0; i<N; i++) {
				sum += mid/time[i];
			}
			
			if(sum < k) {
				start = mid+1;
			}
			
			else{
				
				end = mid-1;
			}
			
		}
		return start;
	}

}
