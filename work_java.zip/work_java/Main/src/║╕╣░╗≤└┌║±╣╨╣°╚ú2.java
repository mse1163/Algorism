import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.StringTokenizer;

public class 보물상자비밀번호2 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {
			StringTokenizer token = new StringTokenizer(br.readLine());
			int N = Integer.parseInt(token.nextToken()); // 숫자의 개수
			int K = Integer.parseInt(token.nextToken()); // 크기 순서
			char[] str = br.readLine().toCharArray();
			
			int size = N / 4;
			for (int i = 0; i < size; i++) {
				// 앞에 3(size)개 출력
				
				for(int j=0; j<N; j+=size) {
					int num = 0;
					for(int k = 0; k< size; k++) {
						System.out.print(str[k+j]);
						int base=0;
						switch(str[k+j]) {
						case 'A': base = 10;  break;
						case 'B': base = 11; break;
						case 'C': base = 12;break;
						case 'D': base = 13;break;
						case 'E': base = 14;break;
						case 'F': base = 15;break;
						default: base = str[k+j]-'0'; break;
						}
						num += (base * Math.pow(16, size-1-k));
					}
					System.out.println(num+" ");
					System.out.println();
				}
				
				
				System.out.println(Arrays.toString(str));
				// 맨 오른쪽꺼를 맨 왼쪽에 넣고 하나씩 오른쪽 이동
				char tmp = str[str.length-1];
				for(int j=N-1; j>0; j--) {
					str[j] = str[j-1];
				}
				str[0] = tmp;
				
			}
			
			
			
			
//			 sb.append("#").append(t).append(" ").append(list.get(list.size()-K)).append("\n");
		}
		bw.write(sb.toString());
		bw.flush();
		bw.close();
	}

}
