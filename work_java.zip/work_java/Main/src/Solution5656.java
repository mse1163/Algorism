import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Solution5656 {
	static class Point{
		int x,y,num;

		public Point(int x, int y, int num) {
			super();
			this.x = x;
			this.y = y;
			this.num = num;
		}

		@Override
		public String toString() {
			return "("+x + ", " + y + "," + num+")";
		}
		
	}
	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {
			StringTokenizer token = new StringTokenizer(br.readLine());
			N = Integer.parseInt(token.nextToken()); // N개 횟수 1 ≤ N ≤ 4

			H = Integer.parseInt(token.nextToken()); // 세로 2 ≤ H ≤ 15
			W = Integer.parseInt(token.nextToken()); // 가로 2 ≤ W ≤ 12

			map = new int[H][W];
			int[][] tmp = new int[H][W];

			for (int i = 0; i < H; i++) {
				token = new StringTokenizer(br.readLine());
				for (int j = 0; j < W; j++) {
					map[i][j] = Integer.parseInt(token.nextToken());
					//tmp[i][j] = map[i][j];
				}
			}

			for (int j = 0; j < W; j++) {
				for (int i = 0; i < H; i++) {
					if (map[i][j] != 0 && tmp[i][j]==0) {
						dfs(tmp, i, j, map[i][j], 0);
						break;
					}
				}
			}
			
			int ans=0;
			for (int j = 0; j < W; j++) {
				for (int i = 0; i < H; i++) {
					if (map[i][j] != 0) {
						ans++;
					}
				}
			}
			
			System.out.println(ans);

		}

	}

	static int N, W, H;
	static int[][] map;

	static int[] dx = { -1, 1, 0, 0 };
	static int[] dy = { 0, 0, -1, 1 };

	static void dfs(int[][] tmp, int x, int y, int num, int cnt) {
		if(cnt==N) {
			return;
		}
		
		if(num==1) {
			tmp[x][y]=1;
			return;
		}
		
		if(num==0) {
			return;
		}
		
		for (int i = 0; i < 4; i++) {
			for (int k = 0; k < num - 1; k++) {
				x += dx[i];
				y += dy[i];
				
				if(x<0 || y<0 || x>=H || y>=W) {
					continue;
				}
				
				tmp[x][y] = 1;
				dfs(tmp, x, y, map[x][y], cnt);
			}
		}
		
		dfs(tmp, x, y, num, cnt+1);
		
		
	}
	
	static Queue<Point> q = new LinkedList<>();
	static void move() {
		while(!q.isEmpty()) {
			Point node = q.poll();
			int x = node.x;
			int y = node.y;
			int num = node.num;
			
			if(num==1) {
				map[x][y]=0;
			}
			else if(num==0) {
				continue;
			}
			else {
				for (int i = 0; i < 4; i++) {
					for (int k = 0; k < num - 1; k++) {
						x += dx[i];
						y += dy[i];
						
						if(x<0 || y<0 || x>=H || y>=W) {
							continue;
						}
						
						q.add(new Point(x, y, map[x][y]));
						map[x][y] = 0;
					}
				}
			}
		}
		
		
		
	}
}
