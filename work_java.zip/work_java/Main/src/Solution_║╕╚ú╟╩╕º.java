import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Solution_보호필름 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {
			StringTokenizer token = new StringTokenizer(br.readLine());
			N = Integer.parseInt(token.nextToken()); // 두께
			M = Integer.parseInt(token.nextToken()); // 가로크기

			K = Integer.parseInt(token.nextToken()); // 합격기준

			map = new int[N][M];

			for (int i = 0; i < N; i++) {
				token = new StringTokenizer(br.readLine());
				for (int j = 0; j < M; j++) {
					map[i][j] = Integer.parseInt(token.nextToken());

				}
			}
			
			ans = 987654321;
			solve(0,0);
			
			sb.append("#").append(t).append(" ").append(ans).append("\n");

		}
		bw.write(sb.toString());
		bw.flush();
		bw.close();
	}

	static int N, M, K;
	static int[][] map;
	static int ans;
	
	static boolean check() {

		for (int j = 0; j < M; j++) {
			int cnt=1;
			boolean isok = false;
			for (int i = 0; i < N-1; i++) {
				if (map[i][j] == map[i + 1][j]) {
					cnt++;
				} else {
					cnt = 1;
				}
				
				if(cnt>=K) {
					isok=true;
					break;
				}
			}
			if(!isok) {
				return false;
			}
		}
		return true;
	}

	static void solve(int cnt, int row) {
		
		if(check()) {
			if(ans > cnt) {
				ans = cnt;
			}
			return;
		}
		
		if(ans<cnt) {
			return;
		}
		
		if(row==N) {
			return;
		}
		
		solve(cnt, row+1);
		
		int[] tmp = new int[M];
		for(int i=0; i<M; i++) {
			tmp[i] = map[row][i];
		}
		
		for(int i=0; i<M; i++) {
			map[row][i] = 0;
			
		}
		
		solve(cnt+1, row+1);
		
		for(int i=0; i<M; i++) {
			map[row][i] = 1;
		}
		
		solve(cnt+1, row+1);
		
		for(int i=0; i<M; i++) {
			map[row][i] = tmp[i];
		}
	}
}
