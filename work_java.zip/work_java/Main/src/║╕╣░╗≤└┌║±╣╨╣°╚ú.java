import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.StringTokenizer;

public class 보물상자비밀번호 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {
			StringTokenizer token = new StringTokenizer(br.readLine());
			int N = Integer.parseInt(token.nextToken()); // 숫자의 개수
			int K = Integer.parseInt(token.nextToken()); // 크기 순서

			String str = br.readLine();
			// 0단계. 입력 잘 받기
			//System.out.println(str);
			// 1.단계. str을 4등분해서 출력하기
			int size = N / 4;
			str = str.substring(str.length() - (size-1), str.length()) + str;
			HashSet<Integer> set = new HashSet<>();
			for (int j = 0; j < size; j++) {
				for (int i = 0; i < N; i += size) {
					String nstr = str.substring(j + i, j + i + size);
					set.add(Integer.parseInt(nstr,16));
					//System.out.println(nstr);
				}
			}
			
			List<Integer> list = new ArrayList<>(set);
			Collections.sort(list);
			 sb.append("#").append(t).append(" ").append(list.get(list.size()-K)).append("\n");
		}
		bw.write(sb.toString());
		bw.flush();
		bw.close();
	}

}
