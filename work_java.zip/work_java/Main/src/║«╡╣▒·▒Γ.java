import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class 벽돌깨기 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {
			StringTokenizer token = new StringTokenizer(br.readLine());
			N = Integer.parseInt(token.nextToken()); // N개 횟수 1 ≤ N ≤ 4

			W = Integer.parseInt(token.nextToken()); // 가로 2 ≤ W ≤ 12
			H = Integer.parseInt(token.nextToken()); // 세로 2 ≤ H ≤ 15

			map = new int[H][W];

			for (int i = 0; i < H; i++) {
				token = new StringTokenizer(br.readLine());
				for (int j = 0; j < W; j++) {
					map[i][j] = Integer.parseInt(token.nextToken());
				}
			}

			ans = 987654321;
			dfs(map, 0);
			sb.append("#").append(t).append(" ").append(ans).append("\n");
		}
		bw.write(sb.toString());
		bw.flush();
		bw.close();

	}

	static int N, W, H;
	static int[][] map;
	// 벽돌 갯수 세기
	static int getCnt(int[][] map) {
		int cnt = 0;
		for (int i = 0; i < H; i++) {
			// System.out.println(Arrays.toString(map[i])); // 디버깅
			for (int j = 0; j < W; j++) {
				if (map[i][j] != 0) {
					cnt++;
				}
			}
		}
		return cnt;
	}

	// 벽돌 아래로 내리기
	static void gravity(int[][] map) {
		for (int i = H - 1; i >= 0; i--) {
			for (int j = 0; j < W; j++) {
				if (map[i][j] == 0) {
					for (int k = i - 1; k >= 0; k--) {
						if (map[k][j] != 0) {
							map[i][j] = map[k][j];
							map[k][j] = 0;
							break;
						}
					}
				}
			}
		}
	}

	// 공 던질 위치 찾기 , 터치기
	static int getBoom(int[][] map, int col) {
		for (int i = 0; i < H; i++) {
			if (map[i][col] != 0) {
				return i;
			}
		}
		return -1;
	}
	
	// 공 던졌을때 터지는 부분 찾기
	static void boom(int[][] map, int x, int y) {

		if (x < 0 || y < 0 || x >= H || y >= W) {
			return;
		}

		int num = map[x][y];
		map[x][y] = 0;

		for (int k = 1; k < num; k++) {
			boom(map, x - k, y);
			boom(map, x + k, y);
			boom(map, x, y - k);
			boom(map, x, y + k);

		}
	}

	static int ans;

	static void dfs(int[][] map, int cnt) {
		if (cnt == N) {
			ans = Math.min(ans, getCnt(map));
			return;
		}

		// 공 한번 던지고
		for (int i = 0; i < W; i++) {
			// 공던질때, 던지기 전의 상태를 복사해서 던짐
			int[][] tmp = new int[H][W];
			deepCopy(map, tmp);
			boom(tmp, getBoom(map, i), i);
			gravity(tmp);
			dfs(tmp, cnt + 1);
		}

	}
	
	// 공 던진후의 상태 맵을 복사
	static void deepCopy(int[][] origin, int[][] clone) {
		for (int i = 0; i < H; i++) {
			for (int j = 0; j < W; j++) {
				clone[i][j] = origin[i][j];
			}
		}

	}

}
