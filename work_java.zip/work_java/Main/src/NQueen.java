import java.util.Scanner;

public class NQueen {

	static int rst = 0;
	static int n;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		Scanner sc = new Scanner(System.in);
		n = sc.nextInt();
		int map[][] = new int[n][n];

		backtrack(map, 0, n);

		System.out.println(rst);
	}

	//
	private static void backtrack(int[][] map, int line, int N) {
		// TODO Auto-generated method stub

		if (line == N) {
			rst++;
			return;
		}

		for (int i = 0; i < N; i++) {
			
			boolean flag=true;
			int left = i;
			int right = i;

			for (int j = line-1; j >= 0; j--) {
				left--;
				right++;
				if (map[j][i] == 1) {
					flag= false;
					break;
				}
				if (left >= 0 && left < N && map[j][left] == 1) {
					flag= false;
					break;
				}
					
				if (right >= 0 && right < N && map[j][right] == 1) {
					flag= false;
					break;
				}
			}
			
			
			if (flag) {
			map[line][i] = 1;
			backtrack(map, line + 1, N);
			map[line][i] = 0;
			}
		}

	}
 
}
