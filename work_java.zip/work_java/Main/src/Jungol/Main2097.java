package Jungol;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Main2097 {
//   static class Point {
//      int x, y;
//
//      public Point(int x, int y) {
//         this.x = x;
//         this.y = y;
//
//      }
//
//      @Override
//      public String toString() {
//         return x + ", " + y;
//      }
//
//   }

   public static void main(String[] args) throws IOException {
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
      BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
     
      StringTokenizer token = new StringTokenizer(br.readLine());

      N = Integer.parseInt(token.nextToken());
      M = Integer.parseInt(token.nextToken());

      map = new int[N + 1][N + 1];
      for (int i = 1; i < N + 1; i++) {
         token = new StringTokenizer(br.readLine());
         for (int j = 1; j < N + 1; j++) {
            map[i][j] = Integer.parseInt(token.nextToken());
         }
      }
      
      dijkstra(1);
      sb.append(dis[M]).append("\n");
      
      sb.append("1 ");
      path(M);
      sb.append(M);
      //sb.append(result);
      
      bw.write(sb.toString());
      bw.flush();
      bw.close();
   }

   static int N, M;
   static int[][] map;
   static int[] dis, path;
   static boolean[] check;
   static String result;
   static  StringBuilder sb = new StringBuilder();
   //static Queue<Integer> q = new LinkedList<>();

   static void dijkstra(int v) {
       dis = new int[N + 1];
 
     check = new boolean[N + 1];
      path = new int[N+1];
      for (int i = 1; i < N + 1; i++) {
         dis[i] = Integer.MAX_VALUE;
      }

      dis[v] = 0;
      check[v] = true;

      for (int i = 1; i < N + 1; i++) {
         if (!check[i] && map[v][i] != 0) {
            dis[i] = map[v][i];
         }
      }

      //System.out.println(Arrays.toString(dis));

      for (int i = 0; i < N - 1; i++) {
        int min = Integer.MAX_VALUE;
         int idx = -1;

         for (int j = 1; j < N + 1; j++) {

            if (!check[j] && dis[j] != Integer.MAX_VALUE) {
               if (dis[j] < min) {
                  min = dis[j];
                  idx = j;
                  //result += " "+j;
               }
            }

         }

         //System.out.println(min + " " + idx + ",");

         check[idx] = true;

         for (int j = 1; j < N + 1; j++) {
           if (!check[j] && map[idx][j] != 0) {
               if (dis[j] > dis[idx] + map[idx][j]) {
                  dis[j] = dis[idx] + map[idx][j];
                  path[j]=idx;
               }
            }
         }

    		 // System.out.println(Arrays.toString(dis));
        // System.out.println(result);
      }
   }
   static void path(int idx) {
  	 if(path[idx]==0) return;
  	 path(path[idx]);
  	 sb.append(path[idx]+" ");
   }

}