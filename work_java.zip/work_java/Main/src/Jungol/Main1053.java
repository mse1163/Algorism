package Jungol;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.math.BigInteger;

public class Main1053 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		while (true) {
			int n = Integer.parseInt(br.readLine());
			if (n == -1) {
				break;
			}

			while (n > 0) {

				n = n - 15000;

			}
			n = n + 15000;
			memo(n);

			System.out.println(memo(n));
		}
	}

	static int[] arr = new int[15001];

	static int memo(int n) {
		arr[0] = 0;
		arr[1] = 1;

		for (int i = 2; i < arr.length; i++) {
			arr[i] = (arr[i - 1] + arr[i - 2]) % 10000;
		}
		// System.out.println(arr[n]);
		return arr[n];
	}

}
