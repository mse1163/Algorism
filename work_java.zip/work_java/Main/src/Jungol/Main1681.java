package Jungol;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Main1681 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		N = Integer.parseInt(br.readLine().trim());

		map = new int[N][N];

		for (int i = 0; i < N; i++) {
			StringTokenizer token = new StringTokenizer(br.readLine().trim());
			for (int j = 0; j < N; j++) {
				map[i][j] = Integer.parseInt(token.nextToken());
			}
		}

//		for (int i = 0; i < N; i++) {
//			for (int j = 0; j < N; j++) {
//				System.out.print(map[i][j] + " ");
//			}
//			System.out.println();
//		}
		sel = new boolean[N];
		min = Integer.MAX_VALUE;
		sel[0]=true;
		dfs(0, 0, 1);
		sb.append(min);
		bw.write(sb.toString());
		bw.flush();
		bw.close();
	}

	// map인접 행렬, sel 방문배열은 하나만 있으면 되므로 static에 둬도 됨
	// current는 현재방문점정, sum은 지금까지 경로총합, 애네들은 매 호출마다 다른 상태를 유지해야되므로 매개변수로 들고 다녀야함
	// 이 재귀함수의 종료조건의 모든 정점 방문은 sel를 모두 돌아보는걸로도 파악 가능하지만
	// 현재까지 몇개를 방문했는지를 cnt변수에 담아서 들고다니면 더 편하게 체크가능
	static int[][] map;
	static boolean[] sel;
	static int N, min;

	static void dfs(int current, int sum, int cnt) {
		
		if(sum>min) {
			return;
		}
		
		// 재귀 종료 조건
		if (cnt == N) {
			if (map[current][0] != 0) {
				sum = sum + map[current][0];
				if (min > sum) {
					min = sum;
				}
			}
			return;
		}
		
		// 다음 호줄 조건
		for (int i = 1; i < N; i++) {
			if (current != i) {
				if (map[current][i] != 0 && !sel[i]) {
					sel[i] = true;
			
					dfs(i, sum + map[current][i], cnt + 1);
					sel[i] = false;
				}
			}
		}

	}

}
