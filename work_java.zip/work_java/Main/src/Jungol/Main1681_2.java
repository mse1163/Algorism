package Jungol;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Main1681_2 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		N = Integer.parseInt(br.readLine().trim());

		map = new int[N][N];

		for (int i = 0; i < N; i++) {
			StringTokenizer token = new StringTokenizer(br.readLine().trim());
			for (int j = 0; j < N; j++) {
				map[i][j] = Integer.parseInt(token.nextToken());
			}
		}

//		for (int i = 0; i < N; i++) {
//			for (int j = 0; j < N; j++) {
//				System.out.print(map[i][j] + " ");
//			}
//			System.out.println();
//		}
		sel = new boolean[N];
		min = Integer.MAX_VALUE;
		sel[0]=true;
		memo = new int[1<<N][N];
		dfs(0, 0, 1);
		sb.append(min);
		bw.write(sb.toString());
		bw.flush();
		bw.close();
	}

	static int[][] map, memo;
	static boolean[] sel;
	static int N, min;

	static int dfs(int status, int current, int cnt) {
		
		if(cnt == map.length-1) {
			if(map[current][0]==0) {
				return 987654321;
			}
			return map[current][0];
		}
		
		// 현재 방문한 상태에서의 최적해가 이미 존재한다면, 아래를 수행하지 않고 알고 있는 최적해를 리턴
		if(memo[status][current]!=0)
			return memo[status][current];
		
		int ret = 987654321;
		for(int i=1; i<N; i++) {
			if(!sel[i] && map[current][i]!=0) {
				sel[i] = true;
				int tmp = dfs(i, cnt+1) + map[current][i];
				sel[i] = false;
				ret = Math.min(tmp, ret);
			}
		}
		// 현재 방문한 상태에서의 최적해를 저장.
		return ret;
		

	}

}
