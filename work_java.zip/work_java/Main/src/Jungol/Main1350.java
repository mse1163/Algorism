package Jungol;

import java.util.ArrayList;
import java.util.Scanner;
 
public class Main1350{
 
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
 
        N = sc.nextInt(); // 정점
        M = sc.nextInt(); // 간선
 
        map = new int[N + 1][N + 1];
        for (int i = 0; i < M; i++) {
            int a = sc.nextInt();
            int b = sc.nextInt();
            int c = sc.nextInt();
 
            if(map[a][b]==0) {
            	map[a][b] = c;
            }
            else {
            	map[a][b]= Math.max(map[a][b], c);
            }
            if(map[b][a]==0) {
            	map[b][a] = c;
            }
            else {
            	map[b][a]= Math.max(map[b][a], c);
            }
            
 
        }
//
//      for (int i = 1; i < N + 1; i++) {
//          for (int j = 1; j < N + 1; j++) {
//              System.out.print(map[i][j] + " ");
//          }
//          System.out.println();
//      }
 
        list = new ArrayList<>();
        sel = new boolean[N + 1];
         
        list.add(1);
        sel[1] = true;
 
        System.out.println(dfs());
 
    }
 
    static int N, M, max;
    static int[][] map;
    static boolean[] sel;
    static ArrayList<Integer> list;
 
    static int dfs() {
        int sum=0;
        for (int k = 1; k < N; k++) {
 
            int max = -1, idx = 0;
 
            for (int i = 0; i < list.size(); i++) {
                int start = list.get(i);
                for (int j = 1; j < N + 1; j++) {
                    if (map[start][j] != 0 && !sel[j]) {
                        if (max < map[start][j]) {
                            max = map[start][j];
                            idx = j;
                        }
                    }
                }
            }
            list.add(idx);
            sum += max;
            sel[idx] = true;
        }
        return sum;
    }
}

