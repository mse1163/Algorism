package Jungol;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;

public class Main1077 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		StringTokenizer token = new StringTokenizer(br.readLine());
		int N = Integer.parseInt(token.nextToken());
		int W = Integer.parseInt(token.nextToken());

		int[][] map = new int[N+1][2];

		int[][] dp = new int[N + 1][W+1];

		for (int i = 1; i < N+1; i++) {
			token = new StringTokenizer(br.readLine());
			map[i][0] = Integer.parseInt(token.nextToken());
			map[i][1] = Integer.parseInt(token.nextToken());
		}

//		Arrays.sort(map, new Comparator<int[]>() {
//
//			@Override
//			public int compare(int[] o1, int[] o2) {
//				// TODO Auto-generated method stub
//				return Integer.compare(o1[0], o2[0]);
//			}
//		});

//		for (int i = 0; i < N; i++) {
//
//			System.out.println(Arrays.toString(map[i]));
//		}

		for (int i = 1; i < N+1; i++) {
			for (int j = 0; j < W+1; j++) {
				if (j < map[i][0])
					dp[i][j] = dp[i - 1][j];
				else {
					
					dp[i][j] = Math.max(dp[i - 1][j], dp[i-1][j-map[i][0]] + map[i][1]);
				}

			}
		}

//		for (int i = 0; i < N+1; i++) {
//
//			System.out.println(Arrays.toString(dp[i]));
//		}
		
		sb.append(dp[N][W]);
		bw.write(sb.toString());
		bw.flush();
		bw.close();
	}

}
