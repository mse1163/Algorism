import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Solution1824 {
	static class Point {
		int x, y;
		char bang;

		public Point(int x, int y, char bang) {
			this.x = x;
			this.y = y;
			this.bang = bang;
		}

		@Override
		public String toString() {
			return x + ", " + y + ", " + bang;
		}

	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {

			StringTokenizer token = new StringTokenizer(br.readLine());
			N = Integer.parseInt(token.nextToken());
			M = Integer.parseInt(token.nextToken());

			map = new char[N][M];

			int idx = 0, idy = 0;
			for (int i = 0; i < N; i++) {
				String str = br.readLine();
				for (int j = 0; j < M; j++) {
					map[i][j] = str.charAt(j);
					if (map[i][j] == '@') {
						idx = i;
						idy = j;
					}
				}
			}

			// location(0, 0, 3, 'R');

			if (idx + dx[0] > 0 && (map[idx + dx[0]][idy + dy[0]] == '<' || map[idx + dx[0]][idy + dy[0]] == '>'
					|| map[idx + dx[0]][idy + dy[0]] == '^')) {
				System.out.println("NO");
			} else if (idx + dx[1] < N && (map[idx + dx[1]][idy + dy[1]] == '<' || map[idx + dx[1]][idy + dy[1]] == '>'
					|| map[idx + dx[1]][idy + dy[1]] == 'v')) {
				System.out.println("NO");
			} else if (idy + dy[2] > 0 && (map[idx + dx[2]][idy + dy[2]] == '^' || map[idx + dx[2]][idy + dy[2]] == 'v'
					|| map[idx + dx[2]][idy + dy[2]] == '>')) {
				System.out.println("NO");
			} else if (idy + dy[3] < M && (map[idx + dx[3]][idy + dy[3]] == '^' || map[idx + dx[3]][idy + dy[3]] == 'v'
					|| map[idx + dx[3]][idy + dy[3]] == '<')) {
				System.out.println("NO");
			} else {
				if (map[0][0] == '<' || map[0][0] == '>' || map[0][0] == '^' || map[0][0] == 'v' || map[0][0] == '_'
						|| map[0][0] == '|' || map[0][0] == '?' || map[0][0] == '.' || map[0][0] == '@'
						|| map[0][0] == '+' || map[0][0] == '-') {
					dfs(0, 0, 'R');
				} else {
					memo = map[0][0] - '0';
					dfs(0, 0, 'R');
				}

			}

			for (int i = 0; i < N; i++) {
				for (int j = 0; j < M; j++) {

					System.out.print(map[i][j] + " ");
				}
				System.out.println();
			}
			if(result==null) {
				result = "NO";
			}
			sb.append("#").append(t).append(" ").append(result).append("\n");
		}
		bw.write(sb.toString());
		bw.flush();
		bw.close();

	}

	static int memo;
	static int N, M;
	static char[][] map;
	static String result;
	static Queue<Point> q = new LinkedList<>();
	static boolean[][][][] visited = new boolean[N][M][4][16]; // 좌표, 방향, 메모리

	static void dfs(int x, int y, char bang) {

		if (bang == 'R') {
			location(x, y, 3, 'R');
		} else if (bang == 'L') {
			location(x, y, 2, 'L');
		} else if (bang == 'U') {
			location(x, y, 0, 'U');
		} else if (bang == 'D') {
			location(x, y, 1, 'D');
		}

	}
//	
//	static void memory(char text) {
//		if(text=='+') {
//			if(memo == 15) {
//				memo = 0;
//			}
//			else {
//				memo = memo+1;
//			}
//		}
//		else if(text=='-') {
//			if(memo == 0) {
//				memo = 15;
//			}
//			else {
//				memo = memo - 1;
//			}
//		}
//	}

	static int[] dx = { -1, 1, 0, 0 };
	static int[] dy = { 0, 0, -1, 1 };

	static void location(int x, int y, int num, char bang) {
		System.out.println(x+","+y);
		visited[x][y][num][memo] = true;

		int nx = x + dx[num];
		int ny = y + dy[num];

		 
			if (nx < 0) {
				dfs(N, ny, bang);
				// q.add(new Point(N, ny, bang));
				return;
			} else if (ny < 0) {
				dfs(nx, M, bang);
				// q.add(new Point(nx, M, bang));
				return;
			} else if (nx >= N) {
				dfs(0, ny, bang);
				// q.add(new Point(0, ny, bang));
				return;
			} else if (ny >= M) {
				dfs(nx, 0, bang);
				// q.add(new Point(nx, 0, bang));
				return;
			}

			if (map[nx][ny] == '_') {
				if (memo == 0) {
					if (!visited[nx][ny][num][memo])
					dfs(nx, ny, 'R');
					// q.add(new Point(nx, ny, 'R'));
				} else {
					if (!visited[nx][ny][num][memo])
					dfs(nx, ny, 'L');
					// q.add(new Point(nx, ny, 'L'));
				}
			} else if (map[nx][ny] == '|') {
				if (memo == 0) {
					if (!visited[nx][ny][num][memo])
					dfs(nx, ny, 'D');
					// q.add(new Point(nx, ny, 'D'));
				} else {
					if (!visited[nx][ny][num][memo])
					dfs(nx, ny, 'U');
					// q.add(new Point(nx, ny, 'U'));
				}
			} else if (map[nx][ny] == '<') {
				if (!visited[nx][ny][num][memo])
				dfs(nx, ny, 'L');
				// q.add(new Point(nx, ny, 'L'));

			} else if (map[nx][ny] == '>') {
				if (!visited[nx][ny][num][memo])
				dfs(nx, ny, 'R');
				// q.add(new Point(nx, ny, 'R'));

			} else if (map[nx][ny] == '^') {
				if (!visited[nx][ny][num][memo])
				dfs(nx, ny, 'U');

				// q.add(new Point(nx, ny, 'U'));

			} else if (map[nx][ny] == 'v') {
				if (!visited[nx][ny][num][memo])
				dfs(nx, ny, 'D');
				// q.add(new Point(nx, ny, 'D'));

			} else if (map[nx][ny] == '?') {
				if (!visited[nx][ny][num][memo]) {
					visited[x][y][num][memo] = true;
					dfs(nx, ny, 'L');
				}
		
				if (!visited[nx][ny][num][memo]) {
					visited[x][y][num][memo] = true;
					dfs(nx, ny, 'R');
				}
				if (!visited[nx][ny][num][memo]) {
					visited[x][y][num][memo] = true;
				dfs(nx, ny, 'U');
				}
				if (!visited[nx][ny][num][memo]) {
					visited[x][y][num][memo] = true;
				dfs(nx, ny, 'D');
				}
//			q.add(new Point(nx, ny, 'L'));
//			q.add(new Point(nx, ny, 'R'));
//			q.add(new Point(nx, ny, 'U'));
//			q.add(new Point(nx, ny, 'D'));

			} else if (map[nx][ny] == '.') {
				return;
			} else if (map[nx][ny] == '@') {
				result = "YES";
				return;
			}

			else if (map[nx][ny] == '+') {
				if (memo == 15) {
					memo = 0;
				} else {
					memo = memo + 1;
				}
				if (!visited[nx][ny][num][memo])
				dfs(nx, ny, bang);
				// q.add(new Point(nx, ny, bang));
			} else if (map[nx][ny] == '-') {
				if (memo == 0) {
					memo = 15;
				} else {
					memo = memo - 1;
				}
				if (!visited[nx][ny][num][memo])
				dfs(nx, ny, bang);
				// q.add(new Point(nx, ny, bang));
			} else {
				memo = map[nx][ny] - '0';
				if (!visited[nx][ny][num][memo])
				dfs(nx, ny, bang);
				// q.add(new Point(nx, ny, bang));
			}

		}
	

}
