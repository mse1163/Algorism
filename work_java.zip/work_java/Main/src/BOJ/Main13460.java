package BOJ;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Main13460 {
	static class Point {
		int x, y;

		public Point(int x, int y) {
			super();
			this.x = x;
			this.y = y;
		}

		@Override
		public String toString() {
			return "Point [x=" + x + ", y=" + y + "]";
		}

	}

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		StringTokenizer token = new StringTokenizer(br.readLine());

		N = Integer.parseInt(token.nextToken());
		M = Integer.parseInt(token.nextToken());

		char[][] map = new char[N][M];

		for (int i = 0; i < N; i++) {
			String str = br.readLine();
			for (int j = 0; j < M; j++) {
				map[i][j] = str.charAt(j);

				if (map[i][j] == 'R') {
					red.add(new Point(i, j));
					
				} else if (map[i][j] == 'B') {
					blue.add(new Point(i, j));
				}
			}
		}

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				System.out.print(map[i][j] + " ");
			}
			System.out.println();
		}

		ans = 987654321;
		Point r = red.poll();
		Point b = blue.poll();
		
		move(map,r.x, r.y, b.x, b.y);
		System.out.println(ans);

	}

	static int N, M, ans;
	static int[] dx = { -1, 1, 0, 0 };
	static int[] dy = { 0, 0, -1, 1 };
	static Queue<Point> red = new LinkedList<>();
	static Queue<Point> blue = new LinkedList<>();

	static void move(char[][] map, int rx, int ry, int bx, int by) {
		
		if(up(map, rx, ry, bx, by)==-1) {
			
		}
		
		down(map, rx, ry, bx, by);
		right(map, rx, ry, bx, by);
		left(map,rx, ry, bx, by);
		
		for(int i=0; i<4; i++) {
			
		}
		
		
		}
		
	static int up(char[][] map, int x, int y, int bx, int by) {
		boolean red= false, blue=false;
		while(true) {
			x += -1;
			y += 0;
			
			if(map[x][y]=='#') {
				break;
			}
			
			else if(map[x][y]=='O') {
				red = true;
				break;
			}
			else {
				continue;
			}
		}
		
		while(true) {
			bx+=-1;
			by+=0;
			
			if(map[bx][by]=='#') {
				break;
			}
			
			else if(map[bx][by]=='O') {
				blue = true;
				break;
			}
			else {
				continue;
			}
		}
		
		if(red && blue) {
			return 0;
			
		}
		else if(red && !blue) {
			return 1;
		}
		else if(!red && blue) {
			return 2;
		}
		
		return -1;
	}
	
	static int down(char[][] map, int x, int y, int bx, int by) {
		boolean red= false, blue=false;
		while(true) {
			x += 1;
			y += 0;
			
			if(map[x][y]=='#') {
				break;
			}
			
			else if(map[x][y]=='O') {
				red = true;
				break;
			}
			else {
				continue;
			}
		}
		
		while(true) {
			bx+= 1;
			by+=0;
			
			if(map[bx][by]=='#') {
				break;
			}
			
			else if(map[bx][by]=='O') {
				blue = true;
				break;
			}
			else {
				continue;
			}
		}
		
		if(red && blue) {
			return 0;
			
		}
		else if(red && !blue) {
			return 1;
		}
		else if(!red && blue) {
			return 2;
		}
		
		return -1;
	}
	
	static int right(char[][] map, int x, int y, int bx, int by) {
		boolean red= false, blue=false;
		while(true) {
			
			y += 1;
			
			if(map[x][y]=='#') {
				break;
			}
			
			else if(map[x][y]=='O') {
				red = true;
				break;
			}
			else {
				continue;
			}
		}
		
		while(true) {
			
			by+= 1;
			
			if(map[bx][by]=='#') {
				break;
			}
			
			else if(map[bx][by]=='O') {
				blue = true;
				break;
			}
			else {
				continue;
			}
		}
		
		if(red && blue) {
			return 0;
			
		}
		else if(red && !blue) {
			return 1;
		}
		else if(!red && blue) {
			return 2;
		}
		
		return -1;
	}
	static int left(char[][] map, int x, int y, int bx, int by) {
		boolean red= false, blue=false;
		while(true) {
			
			y += -1;
			
			if(map[x][y]=='#') {
				break;
			}
			
			else if(map[x][y]=='O') {
				red = true;
				break;
			}
			else {
				continue;
			}
		}
		
		while(true) {
			
			by+= -1;
			
			if(map[bx][by]=='#') {
				break;
			}
			
			else if(map[bx][by]=='O') {
				blue = true;
				break;
			}
			else {
				continue;
			}
		}
		
		if(red && blue) {
			return 0;
			
		}
		else if(red && !blue) {
			return 1;
		}
		else if(!red && blue) {
			return 2;
		}
		
		return -1;
	}
}
