package BOJ;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Main14499 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();
		
		StringTokenizer token = new StringTokenizer(br.readLine());
		N = Integer.parseInt(token.nextToken());	// 세로
		M = Integer.parseInt(token.nextToken());	// 가로
		
		// 시작좌표
		int x = Integer.parseInt(token.nextToken());
		int y = Integer.parseInt(token.nextToken());
		
		// 명령갯수
		int K = Integer.parseInt(token.nextToken());
		
		int[][] map = new int[N][M];
		
		for(int i=0; i<N; i++) {
			token = new StringTokenizer(br.readLine());
			for(int j=0; j<M; j++) {
				map[i][j] = Integer.parseInt(token.nextToken());
			}
		}
		
		token = new StringTokenizer(br.readLine());
		int[] msg = new int[K];
		
		for(int i=0; i<K; i++) {
			msg[i] = Integer.parseInt(token.nextToken());
		}
		

	}
	
	static int N,M;
	static int[] dx = {0,0,-1,1};
	static int[] dy = {1,-1,0,0};
	
	static void dfs() {
		
	}

}
