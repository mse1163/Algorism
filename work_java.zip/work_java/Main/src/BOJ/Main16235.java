package BOJ;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Main16235 {
	static class Point {
		int x,y,age,land;

		public Point(int x, int y, int age, int land) {
			super();
			this.x = x;
			this.y = y;
			this.age = age;
			this.land = land;
		}

		@Override
		public String toString() {
			return "Point [x=" + x + ", y=" + y + ", age=" + age + ", land=" + land + "]";
		}
		
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		StringTokenizer token = new StringTokenizer(br.readLine());

		N = Integer.parseInt(token.nextToken());	// N*N
		M = Integer.parseInt(token.nextToken());	// 심을 나무 갯수
		K = Integer.parseInt(token.nextToken());	// K년 후 
		
		int[][] map = new int[N+1][N+1];
		
		for(int i=1; i<N+1; i++) {
			token = new StringTokenizer(br.readLine());
			for(int j=1; j<N+1; j++) {
				map[i][j] = Integer.parseInt(token.nextToken());
			}
		}
		
		int[][] tree = new int[N+1][N+1];
		
		
		List<Point>[] list = new ArrayList[N*N];
		
		for(int i=0; i<list.length; i++) {
			list[i] = new ArrayList<>();
		}
		
		
		for(int i=0; i<M; i++) {
			token = new StringTokenizer(br.readLine());
			int x = Integer.parseInt(token.nextToken());
			int y = Integer.parseInt(token.nextToken());
			int age = Integer.parseInt(token.nextToken());
			
			list[i].add(new Point(x, y, age, 5));
			
		}
		
		

	}
	
	static int N,M,K;

}
