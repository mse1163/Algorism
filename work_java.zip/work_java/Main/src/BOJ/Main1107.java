package BOJ;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Main1107 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println(Integer.MAX_VALUE);
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int N = Integer.parseInt(br.readLine()); // 누른 숫자
		int M = Integer.parseInt(br.readLine()); // 고장난 숫자갯수

		boolean[] button = new boolean[10];
		if( M != 0) {
			StringTokenizer token = new StringTokenizer(br.readLine());
			for (int i = 0; i < M; i++) {
				int no_button = Integer.parseInt(token.nextToken());
				button[no_button] = true;
			}
			
		}
//		System.out.println(Arrays.toString(button));
		
		// 0부터 500000까지 모두 돌면서 누를 수 있는 숫자 중 가장 N과 가까운 숫자 찾기.
		int minDist = 2147483647;
		int minDistnum = 0;
		for(int i=0; i<=1000000; i++) {
			
			if(canPress(i, button)) {
				int dist = Math.abs(i-N);
				if(minDist > dist) {
					minDist = dist;
					minDistnum = i;
				}
			}
		}
		int cnt = 1;
		while(minDistnum >= 10) {
			minDistnum /= 10;
			cnt++;
		}
		
//		if(minDistnum==0) {
//			cnt=1;
//		}
		int originDist = Math.abs(100-N);
		int distNum = minDist + cnt;
//		System.out.println(minDist + cnt);
		
		int result = Math.min(originDist, distNum);
		
		System.out.println(result);
	}

	static boolean canPress(int N, boolean[] button) {
		boolean isOk = true;

		if (N == 0) {
			return !button[N];
		}

		while (N > 0) {
			int btn = N % 10;
			if (button[btn]) {
				isOk = false;
			}
			N = N / 10;
		}
		return isOk;
	}

}
