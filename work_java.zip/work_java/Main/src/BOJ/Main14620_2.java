package BOJ;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Main14620_2 {
	static class Point {
		int x, y;

		public Point(int x, int y) {
			super();
			this.x = x;
			this.y = y;
		}

		@Override
		public String toString() {
			return "Point [x=" + x + ", y=" + y + "]";
		}

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		N = sc.nextInt();

		int[][] map = new int[N][N];

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				map[i][j] = sc.nextInt();
			}
		}

//		for (int i = 0; i < N; i++) {
//			for (int j = 0; j < N; j++) {
//				System.out.print(map[i][j] + " ");
//			}
//			System.out.println();
//		}

		Point[] flower = new Point[N * N];
		Point[] sel = new Point[3];

		int k = 0;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				flower[k] = new Point(i, j);
				k++;
			}
		}

		ans = 987654321;
		combi(map, flower, sel, 0, 0);

		System.out.println(ans);

	}

	static int N, sum;

	static void combi(int[][] map, Point[] flower, Point[] sel, int cnt, int idx) {
		if (cnt == 3) {
			List<Point> list = new ArrayList<>();
			for (int i = 0; i < 3; i++) {
				list.add(sel[i]);
			}

			if (bfs(map, list)) {
				ans = Math.min(ans, sum);
			}

			return;
		}

		if (idx == flower.length) {
			return;
		}

		sel[cnt] = flower[idx];
		combi(map, flower, sel, cnt + 1, idx + 1);
		combi(map, flower, sel, cnt, idx + 1);
	}

	static int ans;
	static int dx[] = { -1, 1, 0, 0 };
	static int dy[] = { 0, 0, -1, 1 };

	static boolean bfs(int[][] map, List<Point> list) {
		sum = 0;
		boolean[][] sel = new boolean[N][N];
		for (int i = 0; i < list.size(); i++) {
			int x = list.get(i).x;
			int y = list.get(i).y;

			sum += map[x][y];
			sel[x][y] = true;

			for (int j = 0; j < 4; j++) {
				int nx = x + dx[j];
				int ny = y + dy[j];

				if (nx < 0 || ny < 0 || nx >= N || ny >= N || sel[nx][ny]) {
					return false;
				}

				sel[nx][ny] = true;
				sum += map[nx][ny];
			}

		}

		return true;

	}

}
