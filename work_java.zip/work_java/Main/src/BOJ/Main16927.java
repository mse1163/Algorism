package BOJ;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Main16927 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		StringTokenizer token = new StringTokenizer(br.readLine());
		N = Integer.parseInt(token.nextToken());
		M = Integer.parseInt(token.nextToken());

		R = Integer.parseInt(token.nextToken()); // 회전 횟수

		map = new int[N][M];

		for (int i = 0; i < N; i++) {
			token = new StringTokenizer(br.readLine());
			for (int j = 0; j < M; j++) {
				map[i][j] = Integer.parseInt(token.nextToken());
			}
		}

		// 입력확인
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < M; j++) {
				System.out.print(map[i][j] + " ");
			}
			System.out.println();
		}
		
		System.out.println();
		
		for(int n=0; n<R; n++) {
			rocation();
			
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < M; j++) {
					System.out.print(map[i][j] + " ");
				}
				System.out.println();
			}
		}
		

	}

	static int N, M, R;
	static int[][] map;

	static void rocation() {
		for (int i = 0; i < N; i++) {
			int k = i;
			for (int j = 0; j < M; j++) {

				if (i == k) {
					if (j-1 >= k) {
						map[i][j-1] = map[i][j];
					} else {
						map[i+1][j] = map[i][j];
					}
				} else if (j == k) {
					if (i+1 <= N - k)
						map[i+1][j] = map[i][j];
					else
						map[i][j+1] = map[i][j];
				} else if (i == M - k) {
					if (j+1 <= N - k) {
						map[i][j+1] = map[i][j];

					} else {
						map[i-1][j] = map[i][j];

					}
				}

				else if (j == M - k) {
					if (i-1 >= k)
						map[i-1][j] = map[i][j];
					else
						map[i][j-1] = map[i][j];
				}

			}
			k++;
		}

	}
}
