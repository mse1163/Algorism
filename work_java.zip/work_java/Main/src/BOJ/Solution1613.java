package BOJ;

import java.util.Scanner;

public class Solution1613 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int n = sc.nextInt();
		int k = sc.nextInt();
		
		int[][] map = new int[n+1][n+1];
		
		for(int i=1; i<n+1; i++) {
			for(int j=1; j<n+1; j++) {
				map[i][j]=987654321;
			}
		}
		
		for(int i=0; i<k; i++) {
			int a = sc.nextInt();
			int b = sc.nextInt();
			
			map[a][b]=-1;
			map[b][a]=1;
			
		}
		
		for(int mid =1; mid<n+1; mid++) {
			for(int start=1; start<n+1; start++) {
				for(int end=1; end<n+1; end++) {
					if(map[start][end] > map[start][mid]+map[start][mid]) {
						map[start][end] = map[start][mid]+map[start][mid];
					}
				}
			}
		}
		
		int s = sc.nextInt();
		
		for(int i=0; i<s; i++) {
			int a = sc.nextInt();
			int b = sc.nextInt();
			
			if(map[a][b]==-1) {
				System.out.println(-1);
			}
			else if(map[a][b]==1) {
				System.out.println(1);
			}
			else {
				System.out.println(0);
			}
		}

	}

}
