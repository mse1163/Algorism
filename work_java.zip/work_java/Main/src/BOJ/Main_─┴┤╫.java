package BOJ;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Main_컨닝 {

	public static void main(String[] args) throws NumberFormatException, IOException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine().trim());

		for (int t = 1; t <= T; t++) {

			StringTokenizer token = new StringTokenizer(br.readLine());

			int N = Integer.parseInt(token.nextToken());
			int M = Integer.parseInt(token.nextToken());

			char[][] map = new char[N][M];
			for (int i = 0; i < N; i++) {
				String str = br.readLine();
				for (int j = 0; j < M; j++) {
					map[i][j] = str.charAt(j);
				}
			}

//			for (int i = 0; i < N; i++) {
//				for (int j = 0; j < M; j++) {
//					System.out.print(map[i][j] + " ");
//				}
//				System.out.println();
//			}

			int[] dx = { -1, -1, 0, 0 };
			int[] dy = { -1, 1, -1, 1 };
			
			
			int cnt1 = 0;
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < M; j++) {
					boolean isok = false;
					if (map[i][j] == '.' ) {
						

						for (int k = 0; k < 4; k++) {

							int nx = i + dx[k];
							int ny = j + dy[k];

							if (nx < 0 || ny < 0 || nx >= N || ny >= M) {
								continue;
							}

							if (map[nx][ny] == '.') {
								map[nx][ny] = 'x';

							}
							else if( map[nx][ny]=='*') {
								isok = true;
								break;
							}
							
						}
						
						if(!isok) {
							map[i][j]='*';
							cnt1++;
						}
					}
					
				}
//				for (int n = 0; n < N; n++) {
//					for (int m = 0; m < M; m++) {
//						System.out.print(map[n][m] + " ");
//					}
//					System.out.println();
//				}
//				System.out.println();
			}
			
			int cnt2=0;
			for (int i = N-1; i >= 0; i--) {
			for (int j = 0; j < M; j++) {
					boolean isok = false;
					if (map[i][j] == '.' ) {
						

						for (int k = 0; k < 4; k++) {

							int nx = i + dx[k];
							int ny = j + dy[k];

							if (nx < 0 || ny < 0 || nx >= N || ny >= M) {
								continue;
							}

							if (map[nx][ny] == '.') {
								map[nx][ny] = 'x';

							}
							else if( map[nx][ny]=='*') {
								isok = true;
								break;
							}
							
						}
						
						if(!isok) {
							map[i][j]='*';
							cnt2++;
						}
					}
					
				}
//				for (int n = 0; n < N; n++) {
//					for (int m = 0; m < M; m++) {
//						System.out.print(map[n][m] + " ");
//					}
//					System.out.println();
//				}
//				System.out.println();
			}
			
			int ans = 0;
			ans = Math.max(cnt1, cnt2);
			System.out.println(ans);

		}

	}

}
