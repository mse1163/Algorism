package BOJ;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Main16954 {
	static class Point {
		int x, y;

		public Point(int x, int y) {
			super();
			this.x = x;
			this.y = y;
		}

		@Override
		public String toString() {
			return "Point [x=" + x + ", y=" + y + "]";
		}

	}

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		char[][] map = new char[8][8];

		for (int i = 0; i < 8; i++) {
			String str = br.readLine();
			for (int j = 0; j < 8; j++) {
				map[i][j] = str.charAt(j);

				if (map[i][j] == '#') {
					wall.add(new Point(i, j));
				}

			}
		}

		ans = 0;
		q.add(new Point(7, 0));
		move(map, 0);
		System.out.println(ans);
	}
//		// 입력확인
////		for (int i = 0; i < 8; i++) {
////			for (int j = 0; j < 8; j++) {
////				System.out.print(map[i][j] + " ");
////			}
////			System.out.println();
////		}

	static int ans;
	static Queue<Point> q = new LinkedList<>();
	static List<Point> wall = new ArrayList<>();
	static int[] dx = { 0, -1, 1, 0, 0, -1, -1, 1, 1 }; // 상하좌우대각
	static int[] dy = { 0, 0, 0, -1, 1, -1, 1, -1, 1 };

	static void move(char[][] copy, int cnt) {
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				System.out.print(copy[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("-----------------------------------------------------");
		
		if (cnt == 8) {
			if(!q.isEmpty()) {
				ans=1;
			}
			return;
		}

		boolean isok = false;
		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if (copy[i][j] == '#') {
					isok = true;
					break;
				}
			}

			if (isok) {
				break;
			}
		}

		if (!isok) {
			ans = 1;
			return;
		}

		int size = q.size();
		boolean[][] sel= new boolean[8][8];
		for (int k = 0; k < size; k++) {

			Point node = q.poll();

			int x = node.x;
			int y = node.y;

			if (x == 0 && y == 7) {
				ans = 1;
				return;
			}

			if (copy[x][y] == '#') {
				continue;
			}

			for (int i = 0; i < 9; i++) {

				int nx = x + dx[i];
				int ny = y + dy[i];

				if (nx < 0 || ny < 0 || nx >= 8 || ny >= 8) {
					continue;
				}

				if (copy[nx][ny] == '#') {
					continue;
				}

				if (copy[nx][ny] == '.' && !sel[nx][ny]) {
					sel[nx][ny]=true;
					q.add(new Point(nx, ny));
				}

			}
		}

		if (q.isEmpty()) {
			ans = 0;
			return;
		}
		
		char[][] tmp = wallmove(copy);

//		for (int i = 0; i < 8; i++) {
//			for (int j = 0; j < 8; j++) {
//				System.out.print(tmp[i][j] + " ");
//			}
//			System.out.println();
//		}
//		System.out.println();

		move(tmp, cnt + 1);

	}

	static char[][] wallmove(char[][] copy) {
		char[][] tmp = new char[8][8];

		for (int i = 0; i < 8; i++) {
			Arrays.fill(tmp[i], '.');
		}
		
		for (int i = 7; i >= 1; i--) {

			tmp[i] = copy[i - 1];

		}

		return tmp;
	}

	/*
#######. 
######.. 
........ 
........ 
........ 
........ 
........ 
........
	 * 
	  ######## 
	  ######## 
	  ######## 
	  ######## 
	  ######## 
	  ######## 
	  ######## 
	  ########
	 */

}
