import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;

public class Knapsack {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
	static StringTokenizer st;

	
	public static void main(String[] args) throws IOException {
		st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		
		Item[] items = new Item[n];
		
		for(int i=0; i<n; i++) {
			st = new StringTokenizer(br.readLine());
			items[i] = new Item(Integer.parseInt(st.nextToken()), Integer.parseInt(st.nextToken()));
		}//for loop
		
		//items 배열을 score 오름차운으로 정렬
		Arrays.sort(items, new Comparator<Item>() {

			@Override
			public int compare(Item o1, Item o2) {
				// TODO Auto-generated method stub
				return Double.compare(o2.score , o1.score);
			}
		});
		
		dfs(items,0,0,0,k);
		System.out.println(ans);
	}//main

	static int ans=0;
	private static void dfs(Item[] items, int volume, int value ,int idx, int k) {
		// TODO Auto-generated method stub
		if(idx==items.length) {
			if(ans<value)ans=value;
			return;
		}// end option
		
		//현재 idx 부터 남은 아이템들을 무게가 안꽉차면 계쏙 담기
		//배낭 남은 부피가 아이템을 못담으면 쪼개서 담기
		
		//지금까지의 VALUE 로 부터 시작해서 위에처럼 계싼해 나가기
		double bound = value; //현재 까지 획득 가 치
		int cur_volume = volume; // 현재까지 배낭 무게
		
			for(int i=idx; i<items.length; i++) {
				if(cur_volume + items[i].volume <=k) {
					bound += items[i].value;
					cur_volume += items[i].volume;
				}
				else {
					int remain = k - cur_volume; //잔량
					bound +=(remain * items[i].score);
					break;
					//cur_volume = k;
				}
			}
			if(bound <ans)return;
		
		
		 
	if(volume + items[idx].volume <= k) {
		dfs(items, volume + items[idx].volume, value + items[idx].value, idx+1, k);		
		dfs(items, volume, value, idx+1, k );
		}
	}// func dfs
	
}//class


class Item{
	int volume;
	int value;
	double score;
	public Item(int volume, int value) {
		this.volume = volume;
		this.value = value;
		this.score = value/(double)volume;
	}
	
}