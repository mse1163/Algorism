import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Solution3289 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {

			StringTokenizer token = new StringTokenizer(br.readLine());
			n = Integer.parseInt(token.nextToken());
			m = Integer.parseInt(token.nextToken());
			
			parent = new int[n+1];
			rank = new int[n+1];
			makeSet(n+1);
			
			sb.append("#").append(t).append(" ");
	
			for(int i=0; i<m; i++) {
				token = new StringTokenizer(br.readLine());
				
				int x = Integer.parseInt(token.nextToken());
				int a = Integer.parseInt(token.nextToken());
				int b = Integer.parseInt(token.nextToken());
				
				
				if(x==0) {
					union(a,b);
				}
				else {
					if(find(a)==find(b)) {
						sb.append(1);
					}
					else {
						sb.append(0);
					}
				}
				
			}
			sb.append("\n");
		
			
		}
		bw.write(sb.toString());
		bw.flush();
		bw.close();
	}
	
	static int n,m;
	static StringBuilder sb;
	static int[] parent, rank;
	
	static void makeSet(int size) {
		for(int i=1; i<size; i++) {
			parent[i] = i;
			rank[i]=1;
		}
	}
	
	static void union(int x, int y) {
		x = find(x);
		y = find(y);
		
		if(x==y) {
			return;
		}
		
		if(rank[x] < rank[y]) {
			parent[x] = y;
		}
		else {
			parent[y] = x;
		}
		
		if(rank[x]==rank[y]) {
			rank[x]++;
		}
		
	}
	
	static int find(int x) {
		if(parent[x]==x) {
			return x;
		}
		
		return find(parent[x]);
	}

}
