import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Solution4014 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine().trim());

		for (int t = 1; t <= T; t++) {

			StringTokenizer token = new StringTokenizer(br.readLine());

			N = Integer.parseInt(token.nextToken());
			int X = Integer.parseInt(token.nextToken()); // 경사로 길이

			int[][] map = new int[N][N];

			for (int i = 0; i < N; i++) {
				token = new StringTokenizer(br.readLine());
				for (int j = 0; j < N; j++) {
					map[i][j] = Integer.parseInt(token.nextToken());
				}
			}

//			for (int i = 0; i < N; i++) {
//				for (int j = 0; j < N; j++) {
//					System.out.print(map[i][j] + " ");
//				}
//				System.out.println();
//			}

			int ans = 0;
			for (int i = 0; i < N; i++) {
				boolean isok = false;
				boolean[] check = new boolean[N];
				for (int j = 0; j < N - 1; j++) {
					if(map[i][j]==map[i][j+1]) {
						continue;
					}
					else if(map[i][j]+1 == map[i][j+1]) 
					{
						for(int k=0; k<X; k++) {
							if( j-k<0 || map[i][j-k]!=map[i][j] || check[j-k]) {
								check = new boolean[N];
								isok = true;
								break;
							}
							else {
								check[j-k]=true;
							}
						}
					}
					else if(map[i][j]-1 == map[i][j+1]) 
					{
						for(int k=0; k<X; k++) {
							if(j+k+1>=N || map[i][j+k+1]!=map[i][j+1] || check[j+k+1] ) {
								check = new boolean[N];
								isok = true;
								break;
							}
							else {
								check[j+k+1]=true;
							}
						}
					}
					else {
						isok = true;
						break;
					}
				}
					if(!isok) {
//						System.out.println(i);
						ans++;
					}
					
				
			}
			
			// 세로
			for (int j = 0; j < N; j++) {
				boolean isok = false;
				boolean[] check = new boolean[N];
				for (int i = 0; i < N-1; i++) {
					if(map[i][j]==map[i+1][j]) {
						continue;
					}
					else if(map[i][j]+1 == map[i+1][j]) 
					{
						for(int k=0; k<X; k++) {
							if( i-k<0 || map[i-k][j]!=map[i][j] || check[i-k]) {
								check = new boolean[N];
								isok = true;
								break;
							}
							else {
								check[i-k]=true;
							}
						}
					}
					else if(map[i][j]-1 == map[i+1][j]) 
					{
						for(int k=0; k<X; k++) {
							if(i+k+1>=N || map[i+k+1][j]!=map[i+1][j] || check[i+k+1] ) {
								check = new boolean[N];
								isok = true;
								break;
							}
							else {
								check[i+k+1]=true;
							}
						}
					}
					else {
						isok = true;
						break;
					}
				}
					if(!isok) {
//						System.out.println(j);
						ans++;
					}
			}
			
			System.out.println();
			System.out.println(ans);

		}
	}

	static int N;
}
