
public class QuickSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	static void quickSort(int[] arr, int start, int end) {
		if(start>=end) {
			return;
		}
		int pivot = partition(arr, start, end);
		quickSort(arr, start, pivot-1);
		quickSort(arr, pivot+1, end);
	}
	
	
	static int partition(int[] arr, int p, int r) {
		int x  = arr[r];
		int i = p-1;
		for(int j=p; j<r; j++) {
			if(arr[j]<=x) {
				i++;
				swap(arr,i,j);
			}
		}
		swap(arr,i+1,r);
		return i+1;
	}

	private static void swap(int[] arr, int i, int j) {
		// TODO Auto-generated method stub
		int tmp = arr[i];
		arr[i] = arr[j];
		arr[i]=tmp;
	}

	static void power(int a, int n) {
//			n의 log(밑2)구하기
		int k = n;
		int cnt = 0;
		while (k != 1) {
			k /= 2;
			cnt++;
		}
//			 * cnt +1 크기 배열생성
		long[] powMap = new long[cnt + 1];
//			 * 0번칸에는 a , 1번칸 부턴 앞에칸 수를 거듭제곱 저장 1, 2,4,8, 16 ... 저장
		powMap[0]=a;
		for (int i = 1; i < powMap.length; i++) {
			powMap[i] = powMap[i - 1] * powMap[i - 1];
		}
//			 * n을 비트마스킹
		long rst = 1;
		for (int i = 0; i < cnt + 1; i++) {
			//1 을 i 만큼 << 한 n을 연산해서 0이 아니면 해당 인덱스 값을 누적곱
			if((n &(1<<i)) != 0)rst *=powMap[i];
		}
		System.out.println(rst);
	}
			
 
}
