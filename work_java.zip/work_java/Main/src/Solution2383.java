import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.StringTokenizer;

public class Solution2383 {
	static class Point {
		int x, y;

		public Point(int x, int y) {
			super();
			this.x = x;
			this.y = y;

		}

		@Override
		public String toString() {
			return "(" + x + "," + y + ")";
		}

	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {

			int N = Integer.parseInt(br.readLine());

			int[][] map = new int[N][N];
			List<Point> person = new ArrayList<>();
			List<Point> stair = new ArrayList<>();

			for (int i = 0; i < N; i++) {
				StringTokenizer token = new StringTokenizer(br.readLine());
				for (int j = 0; j < N; j++) {
					map[i][j] = Integer.parseInt(token.nextToken());
					if (map[i][j] == 1) {
						person.add(new Point(i, j));
					} else if (map[i][j] != 0 && map[i][j] != 1) {
						stair.add(new Point(i, j));
					}
				}
			}

			// 입력확인
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					System.out.print(map[i][j] + " ");
				}
				System.out.println();
			}

			int[][] first = new int[person.size()][2];
			int[][] second = new int[person.size()][2];

			int first_time = 0;
			int second_time = 0;
			for (int i = 0; i < person.size(); i++) {
				int fx = stair.get(0).x;
				int fy = stair.get(0).y;

				first_time = map[fx][fy];

				int sx = stair.get(1).x;
				int sy = stair.get(1).y;

				second_time = map[sx][sy];

				int px = person.get(i).x;
				int py = person.get(i).y;

				first[i][0] = Math.abs(fx - px) + Math.abs(fy - py);
				first[i][1] = i;

				second[i][0] = Math.abs(sx - px) + Math.abs(sy - py);
				second[i][1] = i;

			}
			
			for (int i = 0; i < first.length; i++) {
				System.out.println(Arrays.toString(first[i]));
			}
			System.out.println();
			for (int i = 0; i < first.length; i++) {
				System.out.println(Arrays.toString(second[i]));
			}

			for (int i = 0; i < first.length; i++) {
				first[i][0] = first[i][0] + first_time + 1;
				second[i][0] = second[i][0] + second_time + 1;
			}

			Arrays.sort(first, new Comparator<int[]>() {

				@Override
				public int compare(int[] o1, int[] o2) {
					// TODO Auto-generated method stub
					return o1[0] - o2[0];
				}

			});

			Arrays.sort(second, new Comparator<int[]>() {

				@Override
				public int compare(int[] o1, int[] o2) {
					// TODO Auto-generated method stub
					return o1[0] - o2[0];
				}

			});
			System.out.println();

			for (int i = 3; i < first.length; i++) {

				first[i][0] = Math.max(first[i][0], first[i - 3][0] + first_time);
				second[i][0] = Math.max(second[i][0], second[i - 3][0] + second_time);

			}

			for (int i = 0; i < first.length; i++) {
				System.out.println(Arrays.toString(first[i]));
			}
			System.out.println();
			for (int i = 0; i < first.length; i++) {
				System.out.println(Arrays.toString(second[i]));
			}

			System.out.println(first_time+" "+ second_time);

			int[] check = new int[person.size()];

			Arrays.sort(first, new Comparator<int[]>() {

				@Override
				public int compare(int[] o1, int[] o2) {
					// TODO Auto-generated method stub
					return o1[1] - o2[1];
				}

			});

			Arrays.sort(second, new Comparator<int[]>() {

				@Override
				public int compare(int[] o1, int[] o2) {
					// TODO Auto-generated method stub
					return o1[1] - o2[1];
				}

			});

			int ans = 0;
			for (int i = 0; i < person.size(); i++) {
				check[i] = Math.min(first[i][0], second[i][0]);
				ans = Math.max(check[i], ans);
			}

			System.out.println(Arrays.toString(check));

			System.out.println("#" + t + " " + ans);

		}

	}

}
