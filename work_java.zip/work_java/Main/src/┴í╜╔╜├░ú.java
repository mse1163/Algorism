import java.util.PriorityQueue;
import java.util.Scanner;

public class 점심시간 {
	static class Person implements Comparable<Person>{
		int x,y;
		int[] dist;
		int sel; // 선택되는 계단
		public Person(int x, int y) {
			this.x = x;
			this.y = y;
			dist = new int[2];	// 계단이 항상 2개
		}
		@Override
		public int compareTo(Person o) {
			// TODO Auto-generated method stub
			return dist[sel] - o.dist[o.sel];
		}
		
	}
	
	static class Point{
		int x, y, height;
		
		public Point(int x, int y, int height) {
			this.x = x;
			this.y = y;
			this.height = height;
		}

		@Override
		public String toString() {
			return x + ", " + y + "," + height;
		}
		
	}
	 public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        int T = sc.nextInt();
	        for(int tc = 1; tc <= T; tc++) {
	            int N = sc.nextInt();
	            int[][] map = new int[N][N];
	            //N*N을 순회하면서, 입력받고.
	            //계단일 경우 계단의 위치와 깊이를 기억  → 계단 하나를 위해 정수 세개가 필요 -> 객체로 처리
	            //사람일 경우 위치를 기억
	            
	           // List<Point> stair = new LinkedList<>();
	           // List<Point> person = new LinkedList<>();
	            int sCnt = 0;
	            int pCnt = 0;
	            Point[] stairs = new Point[2];
	            Person[] person = new Person[10];
	            for(int i=0; i<N; i++) {
	            	for(int j=0; j<N; j++) {
	            		map[i][j] = sc.nextInt();
	            		
	            		if(map[i][j]==1) {
	            			//사람 입력
	            			person[pCnt] = new Person(i,j);
	            			pCnt++;
	            			//person.add(new Point(i, j, map[i][j]));
	            			
	            		}
	            		else if(map[i][j]>1) {
	            			// 계단 입력
	            			stairs[sCnt] = new Point(i,j,map[i][j]);
	            			sCnt++;
	            			//stair.add(new Point(i, j, map[i][j]));
	            		}
	            		else {
	            			continue;
	            		}
	            	
	            	}
	            }
	            
	            // 각 사람별 계단별 거리를 구해주자.
	            for(int i=0; i<pCnt; i++) {
	            	for(int j=0; j< sCnt; j++) {
	            		// 계단 도착후 1분후 내려갈수 있어서 1을 더해줌
	            		person[i].dist[j] = Math.abs(person[i].x - stairs[j].x)+Math.abs(person[i].y - stairs[j].y)+1;
	            		
	            	}
	            }
	            
	            ans = Integer.MAX_VALUE;
	            powerSet(person, stairs, 0, pCnt);
	            System.out.println("#"+tc+" "+ans);
	            
	        }
	    }
	 static int ans;
	 static void powerSet(Person[] person, Point[] stairs, int idx,int pCnt) {
		 if(idx==pCnt) {
			 // 모든 사람에 대해서 계단 배정 완료
//			 // 최대 3명이 계단에 들어갈 수 있다는 조건이 없다면,
//			 // 각 사람별로 선택된 계단까지의 거리 + 선택된 계단의 높이가 밥먹으러 가는 시간
//			 // 위 시간의 최대값이 모두가 점심탈출에 성공하는 시간
//			 int max = 0;
//			 for(int i=0; i<pCnt; i++) {
//				 int time = person[i].dist[person[i].sel] + stairs[person[i].sel].height;
//				 if(max < time) {
//					 max = time;
//				 }
//			 }
			 
			 int[][] stairTimeTable = new int[2][200];
			 // 각 계단별로 먼저 온 놈 순서로 위 타임테이블에 계단에 머무는 시간을 적어보기 위한 큐
			 PriorityQueue<Person>[] stairqueue = new PriorityQueue[2];
			 stairqueue[0] = new PriorityQueue<>();
			 stairqueue[1] = new PriorityQueue<>();
			 
			 for(int i=0; i< pCnt; i++) {
				 // 자신이 배정된 계단의 큐에 추가
				 stairqueue[person[i].sel].add(person[i]);
			 }
			  int max = 0;
	            for(int i = 0; i < stairs.length; i++) {
	                //해당 사람이 타임테이블에서 끝나는 시간
	                int to = 0;
	                 
	                //각 계단의 큐에서 사람을 하나씩 모두 꺼냄
	                while( !stairqueue[i].isEmpty() ) {
	                    Person p = stairqueue[i].poll();
	                    int from = p.dist[p.sel]; //선택된 계단까지의 거리부터 계단을 내려가기 시작
	                    to = from + stairs[p.sel].height; //도착으로부터 계단의 높이만큼의 시간동안 계단에 머뭄
	                    for(int j = from; j < to; j++) {
	                        if( stairTimeTable[p.sel][j] == 3) {
	                            //3명이면 꽉찼으므로, 기록하지 않고 다음 시간으로 이동
	                            to++;
	                            continue;
	                        }
	                        stairTimeTable[p.sel][j]++;//계단시간테이블의 내가 내려가는 계단의 시간에 사람이 있음을 추가
	                    }
	                }
	                 if(max < to) {
	                	 max = to;
	                 }
	            }
	            if( ans > max )
	                ans = max;

			 return;
		 }
		 // 0번 계단 배정 후 호출
		 person[idx].sel = 0;
		 powerSet(person, stairs, idx+1, pCnt);
		 // 1번 계단 배정 후 호출
		 person[idx].sel = 1;
		 powerSet(person, stairs, idx+1, pCnt);
		 
		 
	 }

}
