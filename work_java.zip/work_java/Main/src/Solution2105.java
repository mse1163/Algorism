import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Solution2105 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine().trim());

		for (int t = 1; t <= T; t++) {

			N = Integer.parseInt(br.readLine().trim());

			map = new int[N][N];

			for (int i = 0; i < N; i++) {
				StringTokenizer token = new StringTokenizer(br.readLine());
				for (int j = 0; j < N; j++) {
					map[i][j] = Integer.parseInt(token.nextToken());
				}
			}

			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					System.out.print(map[i][j] + " ");
				}
				System.out.println();
			}

			sx = 0;
			sy = 0;
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					sx = i;
					sy = j;
					sel = new boolean[N][N];
					check = new int[101];
					turn = 0;
					max = -1;
					dfs(i, j, 0, 1);
				}
			}

			System.out.println(max);
		}
	}

	static int N, sx, sy;
	static int[][] map;
	static int turn, max;
	static int[] check;

	// 꺽는 방향
	static int[] lx = { 1, 1, -1, -1 };
	static int[] ly = { 1, -1, -1, 1 };

	static boolean[][] sel;

	static void dfs(int x, int y, int turn, int cnt) {

		// 원위치로 돌아오면 끝
		if (turn == 3) {
			if (sx == x && sy == y) {
				max = Math.max(max, cnt);
				return;
			}
			return;
		}

		int nx = x + lx[turn];
		int ny = y + ly[turn];

		if (nx < 0 || ny < 0 || nx >= N || ny >= N) {
			return;
		}

		if (check[map[nx][ny]] == 0) {
			sel[nx][ny] = true;
			check[map[nx][ny]]++;
			dfs(nx, ny, turn, cnt + 1); // 직진
			dfs(nx, ny, turn + 1, cnt + 1); // 꺽을때
			sel[nx][ny] = false;

		}

	}

//	// 직진
//	static void move_st(int x, int y, int turn, int cnt) {
//		int nx = x + stx[turn];
//		int ny = y + sty[turn];
//		
//		if(nx<0 || ny<0 || nx>=N || ny>N) {
//			return;
//		}
//		
//		if(!sel[nx][ny] && check[map[nx][ny]]==0) {
//			sel[nx][ny] = true;
//			check[map[nx][ny]]++;
//			//dfs(nx, ny, cnt);
//		}
//		
//	}
//	
//	//꺽음
//	static void move_loc(int x, int y, int turn, int cnt) {
//		int nx = x + lx[turn];
//		int ny = y + ly[turn];
//		
//		if(nx<0 || ny<0 || nx>=N || ny>N) {
//			return;
//		}
//		
//		if(!sel[nx][ny]&& check[map[nx][ny]]==0) {
//			sel[nx][ny] = true;
//			check[map[nx][ny]]++;
//			//dfs(nx, ny, cnt);
//		}
//		
//	}

}
