import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class 수영장_dp{

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {
			StringTokenizer token = new StringTokenizer(br.readLine());

			int[] price = new int[4];
			for (int i = 0; i < 4; i++) {
				price[i] = Integer.parseInt(token.nextToken());
			}

			int[] plan = new int[12];

			token = new StringTokenizer(br.readLine());
			for (int i = 0; i < 12; i++) {
				plan[i] = Integer.parseInt(token.nextToken());
			}
			
			System.out.println(Arrays.toString(plan));
			
			int[] dp = new int[13];
			for(int i=1; i<13; i++) {
				
				if(dp[i]==0) {
					dp[i] = dp[i-1];
					continue;
				}
				
				dp[i] = Math.min(dp[i-1]+plan[i-1]*price[0], price[1]);
				if(i>=3) {
					dp[i] = Math.min(dp[i-3]+price[2], dp[i]);
				}
			}
			int result = Math.min(dp[13], price[3]);
			System.out.println(result);
			
		}
	}

}
