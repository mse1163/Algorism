import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Solution {

	static int r, c, n, rst;
	static int map[][];

	static int dx[] = { -1, 1, 0, 0 };
	static int dy[] = { 0, 0, -1, 1 };

	static final int up = 0;
	static final int down = 1;
	static final int left = 2;
	static final int right = 3;

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		int tc = Integer.parseInt(br.readLine());

		for (int T = 1; T <= tc; T++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			n = Integer.parseInt(st.nextToken());
			c = Integer.parseInt(st.nextToken());
			r = Integer.parseInt(st.nextToken());

			map = new int[r][c];
			rst = Integer.MAX_VALUE;
			for (int i = 0; i < r; i++) {
				st = new StringTokenizer(br.readLine());
				for (int j = 0; j < c; j++) {
					map[i][j] = Integer.parseInt(st.nextToken());
				}
			} // insert

			 
				dfs(map, 0, 0);
		 

			System.out.println("#" + T + " " + rst);

		} // test_case

	}// main

	private static void dfs(int map[][], int cur, int depth) {
		// TODO Auto-generated method stub
		int tmp[][] = new int[r][c];
		if (depth == n) {
//			System.out.println("========================");
//			for(int i=0; i<r; i++) {
//				System.out.println(Arrays.toString(map[i]));
//			}
			int cnt = 0;
			for (int i = 0; i < r; i++) {
				for (int j = 0; j < c; j++) {
					if (map[i][j] != 0)
						cnt++;
				}
			}
			rst = Math.min(rst, cnt);
			return;
		} // end option

		// ball down
		// backtracking
		for (int back = cur; back < c; back++) {
					
		
		tmp = deepcopy(tmp,map);
		
		for (int i = 0; i < r; i++) {
			if (tmp[i][cur] != 0) {
				// 떨어트린 구슬이 1인경우 그냥 지우기
				if (tmp[i][cur] == 1) {
					tmp[i][cur] = 0;
					break;
				}
				// 떨어트린 구슬이 1보다 큰 블록을 만나면
				else if (tmp[i][cur] > 1) {
					boolean vis[][] = new boolean[r][c];
					tmp = bomb(i, cur, tmp[i][cur], tmp, vis);
					break;
				}
			}
		}
		// gravity
		tmp = gravity(tmp);

		dfs(tmp, back, depth + 1);
		
		map = deepcopy(map,tmp);
		}
	}

	private static int[][] deepcopy(int[][] tmp, int[][] map) {
		// TODO Auto-generated method stub
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				tmp[i][j] = map[i][j];
			}
		} // deep copy
		return tmp;
	}

	private static int[][] gravity(int[][] tmp) {
		// TODO Auto-generated method stub
		Queue<Integer> q = new LinkedList<>();
		for (int i = 0; i < c; i++) {
			for (int j = r - 1; j >= 0; j--) {
				if (tmp[j][i] != 0)
					q.add(tmp[j][i]);
				tmp[j][i] = 0;
			}

			int qsize = q.size();
			for (int j = r - 1; j >= r - qsize; j--) {
				tmp[j][i] = q.poll();
			}
		}

		return tmp;
	}

	private static int[][] bomb(int x, int y, int size, int[][] tmp, boolean vis[][]) {
		// TODO Auto-generated method stub
		tmp[x][y] = 0;
		// left
		for (int i = y; i > y - size && i >= 0; i--) {
			if (tmp[x][i] == 1)
				tmp[x][i] = 0;
			else if (tmp[x][i] > 1)
				vis[x][i] = true;
		}
		// right
		for (int i = y; i < y + size && i < c; i++) {
			if (tmp[x][i] == 1)
				tmp[x][i] = 0;
			else if (tmp[x][i] > 1)
				vis[x][i] = true;
		}
		// up
		for (int i = x; i > x - size && i >= 0; i--) {
			if (tmp[i][y] == 1)
				tmp[i][y] = 0;
			else if (tmp[i][y] > 1)
				vis[i][y] = true;
		}
		// down
		for (int i = x; i < x + size && i < r; i++) {
			if (tmp[i][y] == 1)
				tmp[i][y] = 0;
			else if (tmp[i][y] > 1)
				vis[i][y] = true;
		}
		// 만약 번질곳이 더 있다면 다시 bomb 해주기
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				if (vis[i][j]) {
					vis[i][j] = false;
					bomb(i, j, tmp[i][j], tmp, vis);
				}
			}
		}
		return tmp;
	}

}// class
