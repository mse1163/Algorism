import java.util.Arrays;

public class disjointset {
	
	static int[] parents;
	static int[] rank;
	
	/*
	 * 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parents = new int[5];
		rank = new int[5];
		for(int i=0; i<parents.length; i++) {
			makeSet(i);
		}
		union(0,1);
		System.out.println(Arrays.toString(parents));
		
		union(2,3);
		union(0,3);
		union(4,5);
		union(2,4);
	}

	static void makeSet(int x ) {
		parents[x]=x;
	}
	
	static int findSet(int x) {
		if(parents[x]==x)return x;
		else return findSet(parents[x]);
		
		
	}
	
	static void union(int x, int y) {
		int parentsX = findSet(x);
		int parentsY = findSet(y);
		
		if(rank[parentsX] > rank[parentsY]) {
			parents[parentsY] = parentsX;
		}
		else {
			parents[parentsX] = parentsY;
			if(rank[parentsX] == rank[parentsY])rank[parentsY]++;
		}
	}
		
}
