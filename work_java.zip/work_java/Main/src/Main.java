import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Main {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		int vis[] = new int[3];
		
			dfs(0,0,vis);
		
	}

	private static void dfs(int cur, int depth, int vis[]) {
		// TODO Auto-generated method stub
		if(depth ==3) {
			System.out.println(Arrays.toString(vis));
			return;
		}
		
		for(int i=cur; i<3; i++) {
			vis[i]++;
			dfs(i,depth+1,vis);
			vis[i]--;
		}
	}
}
