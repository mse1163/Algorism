import java.io.IOException;
import java.util.Scanner;

public class Solution4796 {

	public static void main(String[] args) throws NumberFormatException, IOException {

		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();

		for (int t = 1; t <= T; t++) {
			int N = sc.nextInt();
			int[] height = new int[N];

			for (int i = 0; i < N; i++) {
				height[i] = sc.nextInt();
			}

			int cnt = 0;
			int up = 0, down = 0;
			for (int i = 0; i < N - 1; i++) {
				if (height[i] < height[i + 1]) {
					if (down == 0) {
						up++;
						continue;
					}

				} else {
					
						down++;
						continue;
				}
				cnt += up * down;
				up = 0;
				down = 0;
				i = i - 1;

			}
			if(cnt==0) {
				cnt = up * down;
			}
			System.out.println("#" + t + " " + cnt);
		}
	}

}
