
public class ParrternMathcing {
	public static void main(String[] args) {
	
	}
}
