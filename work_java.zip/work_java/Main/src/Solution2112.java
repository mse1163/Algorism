import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Solution2112 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine());

		for (int t = 1; t <= T; t++) {
			StringTokenizer token = new StringTokenizer(br.readLine());
			N = Integer.parseInt(token.nextToken()); // 두께
			M = Integer.parseInt(token.nextToken()); // 가로크기

			K = Integer.parseInt(token.nextToken()); // 합격기준

			map = new int[N][M];

			for (int i = 0; i < N; i++) {
				token = new StringTokenizer(br.readLine());
				for (int j = 0; j < M; j++) {
					map[i][j] = Integer.parseInt(token.nextToken());

				}
			}

//			for (int i = 0; i < N; i++) {
//				for (int j = 0; j < M; j++) {
//					System.out.print(map[i][j] + " ");
//
//				}
//				System.out.println();
//			}

			// 현재 필름 상태 통과인지 검사
			// A => 0 , B=>1
			ans = 987654321;
			solve(0, 0);
			// 각 행을 안/A/B 로 바꿔보기 위해 사용할 재귀함수 원형 작성
			System.out.println("#" + t + " " + ans);
		}

	}

	static int[][] map;
	static int N, M, K, ans;

	static void solve(int cnt, int row) {

		if (isOk()) {
			if (ans > cnt)
				ans = cnt;
			return;
		}
		if (ans < cnt)
			return;

		if (row == N) {
			return;
		}

		// row행에 대해서 안바꾸고 다음 행 검사하러 가는 경우
		solve(cnt, row + 1);

		int[] tmp = new int[M];
		for (int i = 0; i < M; i++) {
			tmp[i] = map[row][i];
		}

		// row행에 대해서 A로 바꾸고 다음 행으로 넘어가는 경우
		for (int i = 0; i < M; i++) {
			map[row][i] = 0;
		}
		// row행의 모든 셀로 변경ㅋ
		solve(cnt + 1, row + 1);

		// row행의 모든 셀을 B로 변경
		for (int i = 0; i < M; i++) {
			map[row][i] = 1;
		}
		solve(cnt + 1, row + 1);

		// 76번 라인에서 A로 변경했던 셀을 원래값으로 되돌려놓기(백트래킹)
		for (int i = 0; i < M; i++) {
			map[row][i] = tmp[i];
		}

	}

	// 같은 숫자 3개인지 확인
	static boolean isOk() {
		for (int j = 0; j < M; j++) {
			int cnt = 1;
			boolean isok = false;
			for (int i = 0; i < N - 1; i++) {
				if (map[i][j] == map[i + 1][j]) {
					cnt++;
				} 
				else {
					cnt = 1;
				}

				if (cnt >= K) {
					isok = true;
					break;
				}
			}
			if (!isok)
				return false;
		}
		return true;
	}

}
