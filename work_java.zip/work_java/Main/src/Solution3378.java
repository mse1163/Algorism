import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Solution3378 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();
		
		int T = Integer.parseInt(br.readLine());
		
		for(int t=1; t<=T; t++) {
			
			StringTokenizer token = new StringTokenizer(br.readLine());
			int p = Integer.parseInt(token.nextToken());
			int q = Integer.parseInt(token.nextToken());
			
			String[] code= new String[p];
			for(int i=0; i<p; i++) {
				code[i] = br.readLine();
				
			}
			
			String[] code_me = new String[q];
			for(int i=0; i<q; i++) {
				code_me[i] = br.readLine();
			}
			
			System.out.println(Arrays.toString(code));
			System.out.println(Arrays.toString(code_me));
			
			int[] text = new int[6];
			
			R=0; C=0; S=0;
			int dot=0;
			for(int i=0; i<p; i++) {
				
				RCS(text,dot);
				
				dot=0;

				for(int j=0; j<code[i].length(); j++) {
					
					char c = code[i].charAt(j);
					if(c=='(') {
						text[0]++;
					}
					else if(c==')') {
						text[1]++;
					}
					else if(c=='{') {
						text[2]++;
					}
					else if(c=='}') {
						text[3]++;
					}
					else if(c=='[') {
						text[4]++;
					}
					else if(c==']') {
						text[5]++;
					}
					else if(c=='.') 
					{	
						if(j==0) {
							dot++;
						}
						else {
							if(code[i].charAt(j-1)=='.') {
								dot++;
							}
						}
					}
				
					
				}
				System.out.println(dot);
				System.out.println(Arrays.toString(text));
				
				
			}
			
			System.out.println(R+" "+C+" "+S);
			
			
		}
		

	}
	
	static int R,C,S;
	static void RCS(int[] text, int dot) {

		
		if(text[0]-text[1]!=0 && (text[2]-text[3])==0 && (text[4]-text[5])==0) {
			R = dot/(text[0]-text[1]);
		}
		else if(text[0]-text[1] ==0 && (text[2]-text[3])!=0 && (text[4]-text[5])==0) {
			C = dot/(text[2]-text[3]);
		}
		else if(text[0]-text[1] ==0 && (text[2]-text[3])==0 && (text[4]-text[5])!=0) {
			S = dot/(text[4]-text[5]);
		}
		else if(text[0]-text[1] ==0 && (text[2]-text[3])!=0 && (text[4]-text[5])!=0) {
			if(C!=0) {
				S = dot - (C*(text[2]-text[3]));
			}
			else if(S!=0){
				C = dot - (S*(text[4]-text[5]));
			}
		}
		else if(text[0]-text[1] !=0 && (text[2]-text[3])==0 && (text[4]-text[5])!=0) {
			if(R!=0) {
				S = dot - (R*(text[0]-text[1]));
			}
			else if(S!=0){
				R = dot - (S*(text[4]-text[5]));
			}
		}
		else if(text[0]-text[1] !=0 && (text[2]-text[3])!=0 && (text[4]-text[5])==0) {
			if(R!=0) {
				C = dot - (R*(text[0]-text[1]));
			}
			else if(C!=0){
				R = dot - (C*(text[2]-text[3]));
			}
		}
		
		
		
	}

}
