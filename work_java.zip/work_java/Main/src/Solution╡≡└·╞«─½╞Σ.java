import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Solution디저트카페 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();

		int T = Integer.parseInt(br.readLine().trim());

		for (int t = 1; t <= T; t++) {

			N = Integer.parseInt(br.readLine().trim());

			map = new int[N][N];

			for (int i = 0; i < N; i++) {
				StringTokenizer token = new StringTokenizer(br.readLine());
				for (int j = 0; j < N; j++) {
					map[i][j] = Integer.parseInt(token.nextToken());
				}
			}

//			for (int i = 0; i < N; i++) {
//				for (int j = 0; j < N; j++) {
//					System.out.print(map[i][j] + " ");
//				}
//				System.out.println();
//			}

			max=-1;
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					check = new int[101];
					dfs(i, j, 0, 0,i,j);
				}
			}
			
			sb.append("#").append(t).append(" ").append(max).append("\n");
		}
		bw.write(sb.toString());
		bw.flush();
		bw.close();
	}

	static int N, sx, sy;
	static int[][] map;
	static int max;
	static int[] check;

	// 꺽는 방향
	static int[] lx = { 1, 1, -1, -1 };
	static int[] ly = { 1, -1, -1, 1 };

	static void dfs(int x, int y, int turn, int cnt, int sx, int sy) {

		// 원위치로 돌아오면 끝
		if(sx == x && sy == y && turn==3) {
			//System.out.println(cnt);
			max = Math.max(max, cnt);
			return;
		}
		
		
		for(int i = turn; i<= turn+1 && i<4; i++) {
			int nx = x + lx[i];
			int ny = y + ly[i];
			
			if (nx < 0 || ny < 0 || nx >= N || ny >= N) {
				continue;
			}
			
			if(check[map[nx][ny]]==1) {
				continue;
			}
			
			check[map[nx][ny]]=1;
			dfs(nx, ny, i, cnt+1, sx, sy);
			check[map[nx][ny]]=0;
			
		}

	}

}
