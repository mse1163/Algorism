import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Main14889 {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		StringBuilder sb = new StringBuilder();
		
		N = Integer.parseInt(br.readLine());
		
		map = new int[N][N];
		
		for(int i=0; i<N; i++) {
			StringTokenizer token = new StringTokenizer(br.readLine());
			for(int j=0; j<N; j++) {
				map[i][j]=Integer.parseInt(token.nextToken());
			}
		}

//		for(int i=0; i<N; i++) {
//			for(int j=0; j<N; j++) {
//				System.out.print(map[i][j]+" ");
//			}
//			System.out.println();
//		}
		
		arr = new int[N];
		for(int i=0; i<N; i++) {
			arr[i] = i;
		}
		sel = new boolean[N];
		min = Integer.MAX_VALUE;
//		team1 = new ArrayList<>();
//		team2 = new ArrayList<>();
		combi(0,0);
		
//		for(int i=0; i<team1.size(); i++) {
//			System.out.print(team1.get(i)+" ");
//		}
//		System.out.println();
//		for(int i=0; i<team1.size(); i++) {
//			System.out.print(team2.get(i)+" ");
//		}
		
		

		
		System.out.println(min);
		
	}

	static int N;
	static int[][] map;
	static boolean[] sel;
	static int[] arr;
	static ArrayList<Integer> team1, team2;
	static int min;
	
	static void result() {
		int sum1=0; int sum2=0;
		for(int i=0; i<N/2; i++) {
			int x1 = team1.get(i);
			int x2 = team2.get(i);
			for(int j=i+1; j<N/2; j++) {
				int y1 = team1.get(j);
				int y2 = team2.get(j);
				sum1 += map[x1][y1]+map[y1][x1];
				sum2 += map[x2][y2]+map[y2][x2];
				
			}
		}
		int result =Math.abs(sum1-sum2);
		
		min = Math.min(result, min);
		
	}
	
	static void combi(int idx,int cnt) {
		if(cnt==N/2) {
			team1 = new ArrayList<>();
			team2 = new ArrayList<>();
			
			for(int i=0; i<N; i++) {
				if(sel[i]) {
					team1.add(arr[i]);
				}
				else {
					team2.add(arr[i]);
				}
			}
			
			result();
			
			return;
		}
		
		if(idx==arr.length) {
			return;
		}
		
		sel[idx] = true;
		combi(idx+1,cnt+1);
		sel[idx] = false;
		combi(idx+1, cnt);
	}
	
}
