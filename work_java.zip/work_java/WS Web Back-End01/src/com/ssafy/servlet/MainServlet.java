package com.ssafy.servlet;


import java.io.IOException;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.javafx.collections.MappingChange.Map;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/main")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("id");
		String pass = request.getParameter("pass");
		String url = "Login.html";
		if(id.equals("ssafy") && pass.equals("1111")) {
			request.setAttribute("id", id);
			url = "LoginSuccess.jsp";
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");
		
		String isbn = request.getParameter("isbn1")+"-"+request.getParameter("isbn2")+"-"+request.getParameter("isbn3");
		String title = request.getParameter("title");
		String cat = request.getParameter("category");
		String country = request.getParameter("country");
		String pubDate = request.getParameter("date");
		
		String[] publisher = request.getParameterValues("publisher");
		
		
		String author = request.getParameter("author");
		String price = request.getParameter("price") + request.getParameter("unit");
		String desc = request.getParameter("desc");
		
		StringBuilder sb = new StringBuilder("<html><body><table>");
		sb.append("<tr><td colspan='2'>도서정보</td><tr>");
		sb.append("<tr><td>도서명</td><td>"+title+"</td></tr>");
		sb.append("<tr><td>도서번호</td><td>"+isbn+"</td></tr>");
		sb.append("<tr><td>도서분류</td><td>"+cat+"</td></tr>");
		sb.append("<tr><td>도서국가</td><td>"+country+"</td></tr>");
		sb.append("<tr><td>출판사</td><td>"+publisher+"</td></tr>");
		sb.append("<tr><td>저자</td><td>"+author+"</td></tr>");
		sb.append("<tr><td>도서가격</td><td>"+price+"</td></tr>");
		sb.append("<tr><td>출판일</td><td>"+pubDate+"</td></tr>");
		sb.append("<tr><td>설명</td><td>"+desc+"</td></tr>");
		sb.append("</table></body></html>");
		response.getWriter().append(sb.toString());
	}

}
