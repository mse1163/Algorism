package jdbcTest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookDao {
	private Connection conn;

	private BookDao() {
		try {
			conn = DriverManager.getConnection(
					"jdbc:mysql://127.0.0.1/day02?characterEncoding=UTF-8&serverTimezone=UTC", "root", "1234");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static BookDao instance;

	public static BookDao getInstance() {
		if (instance == null)
			instance = new BookDao();
		return instance;
	}

	/**
	 * 책 한권의 정보를 데이터베이스에 삽입하는 기능
	 * 
	 * @param book 책 한권에 대한 정보가 BookVO타입으로 전달되어짐
	 * @return 쿼리문 수행에 의해 영향을 받은 레코드의 수를 리턴
	 *
	 */

	public int insertBook(BookVO book) {
		String sql = "insert into books values(0,?,?,?,?)";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,  book.getTitle());
			pstmt.setString(2,  book.getPublisher());
			pstmt.setString(3,  book.getYear());
			pstmt.setInt(4,  book.getPrice());
			return pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return -1;
	}
	
	public int updateBook(BookVO book) {
		// book하나의 정보를 받아서, 해당 book객체의 아이디에 해당하는 레코드의 나머지 정보를 book객체의 정보들로 변경
		String sql = "update books set title=?, publisher=?, year=?, price=? where book_id = ?";
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,  book.getTitle());
			pstmt.setString(2,  book.getPublisher());
			pstmt.setString(3,  book.getYear());
			pstmt.setInt(4,  book.getPrice());
			pstmt.setInt(5, book.getBookid());
			return pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return -1;
	}
	
	public int deleteBook(int bookid) {
		//bookid에 해당하는 레코드 삭제
		String sql = "delete from books where book_id = ?";
		PreparedStatement pstmt = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, bookid);
			
			return pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return -1;
	}
	
	public List<BookVO> selectAll(){
		//conn을 이용해 select문을 날리고 조회된 모든 책의 정보를 리스트로 만들어 리턴하시오.
		
		List<BookVO> list = new ArrayList<>();
		String sql = "select*from books";
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				
				BookVO vo = new BookVO();
				vo.setBookid(rs.getInt(1));
				vo.setTitle(rs.getString(2));
				vo.setPublisher(rs.getString(3));
				vo.setYear(rs.getString(4));
				vo.setPrice(rs.getInt(5));
				
				list.add(vo);
//				list.add(new BookVO(rs.getInt("book_id"), rs.getString("title"), rs.getString("publisher"), rs.getString("year"), rs.getInt("price")));
				
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
				else if (pstmt != null) {
					pstmt.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return list;
		
	}
	
	public BookVO selectOne(int bookid) {
		String sql = "select * from books where book_id=?";
		BookVO book = null;
		
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, bookid);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				book = new BookVO();
				book.setBookid(rs.getInt("book_id"));
				book.setTitle(rs.getString("title"));
				book.setPublisher(rs.getString("publisher"));
				book.setYear(rs.getString("year"));
				book.setPrice(rs.getInt("price"));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return book;
		
	}
}
