package jdbcTest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class InsertBook {
	static Connection conn;
	static {
		try {
			conn = 
					DriverManager.getConnection("jdbc:mysql://127.0.0.1/day02?characterEncoding=UTF-8&serverTimezone=UTC", "root", "1234");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		//JDBC연결은 창고단위로 연결이 이뤄짐. 우리는 day02창고에 접속해서 
		// insert into books values(0, 'jdbc연동 실습', '싸피출판사', '2019', 50000)
		// 이라는 SQL을 던지고 성공여부를 출력하는 프로그램을 만들어봅시다 :)
		
		// 드라이버 적재
		
		Scanner sc = new Scanner(System.in);
		
//			Class.forName("com.mysql.jdbc.Driver");
			// 디비 연결을 위한 정보는, 디비서버의 주소, 그 서버안에 접속할 창고이름, 유저명, 비밀번호
			// jdbc:mysql://ip주소/창고
			// jdbc:mysql://127.0.0.1/day02
			// root
			// 1234
			
			String title = sc.nextLine();
			String publisher = sc.nextLine();
			String year = sc.nextLine();
			int price = sc.nextInt();
			sc.nextLine();
			
//			System.out.println(conn.isClosed());

			insertBook(title, publisher, year, price);
			
			//stmt를 제출하는 함수는 3가지
			//execute(): for DDL(create table, alter table...)
			//executeUpdate(): for DML (insert, update...)
			//executeQuery(): for DQL(select)

	}
	
	static void insertBook(String title, String publisher, String year, int price) {
		String sql = "insert into books values(0,?,?,?,?)";
		PreparedStatement pstmt;
		try {
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, title);	// 첫번째 물음표를 title변수의 값으로 문자열 형태로 채워주세요...
			pstmt.setString(2, publisher);
			pstmt.setString(3, year);
			pstmt.setInt(4, price);
			
			int res = pstmt.executeUpdate();
			System.out.println(res + "Success");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

}
