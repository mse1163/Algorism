package jdbcTest;

public class BookDaoTest {
	public static void main(String[] args) {
		
		BookDao dao = BookDao.getInstance();
		
		BookVO book = new BookVO();
//		book.setTitle("JDBC is Nogarding");
//		book.setPublisher("Hello World");
//		book.setYear("1995");
//		book.setPrice(1000000);
		
//		int res = dao.insertBook(book);
//		System.out.println(res + "Success");
//		
//		book.setTitle("JDBC is Nogarding");
//		book.setPublisher("Hello World");
//		book.setYear("1988");
//		book.setPrice(5000);
//		book.setBookid(9);
		
//		int res2 = dao.updateBook(book);
		int res3 = dao.deleteBook(9);
		System.out.println(res3 + "Success");
		
	}
}
