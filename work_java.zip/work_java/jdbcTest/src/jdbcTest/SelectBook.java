package jdbcTest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SelectBook {

	public static void main(String[] args) {
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1/day02?characterEncoding=UTF-8&serverTimezone=UTC", "root", "1234");
			// SQL문은 Statement(PreparedStatement) 객체에 실어서 보낸다. executeQuery()를 통해서..
			// 결과로 튀어나오는 ResultSet객체로부터 원하는 값을 회수
			String sql = "select*from books";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString("title"));
				
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}

}
