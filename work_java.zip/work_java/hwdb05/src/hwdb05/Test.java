package hwdb05;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		ProductDAO dao = ProductDAO.getInstance();
		
		// 삽입
		Product pro = new Product();
		pro.setCode("AI5120");
		pro.setName("삼송TV");
		pro.setPrice(320000);
		
		int res = dao.insertProduct(pro);
		System.out.println(res + "Success");
		
		List<Product> list = dao.selectAll();
		for(Product p : list) {
			System.out.println(p.toString());
		}
		
		// 수정
		Product pro2 = new Product();
		pro2.setCode("AI5120");
		pro2.setName("삼송TV33");
		pro2.setPrice(320000);
		int res2 = dao.updateProduct(pro2);
		
		System.out.println(res2);
		
		List<Product> list2 = dao.selectAll();
		for(Product p : list2) {
			System.out.println(p.toString());
		}
		
		// 삭제
		int res3 = dao.deleteProduct("AI5120");
		
		System.out.println(res3);
		
		List<Product> list3 = dao.selectAll();
		for(Product p : list3) {
			System.out.println(p.toString());
		}
		
	}

}
