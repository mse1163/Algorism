package com.ssafy.book;

import java.util.LinkedList;
import java.util.List;

public class BookMgr {
	
	private BookMgr() {
		
	}
	private static BookMgr service = new BookMgr();
	
	public static BookMgr getService() {
		return service;
	}
	
	List<Book> books = new LinkedList<>();

	public void add(Book b) {
		books.add(b);
	}

	public List<Book> search() {
		return books;

	}

	public List<Book> searchByIsbn(String isbn) {
		List<Book> list = new LinkedList<>();
		for (int i = 0; i < books.size(); i++) {
			if (books.get(i).isbn.equals(isbn)) {
				list.add(books.get(i));
			}
		}
		
		return list;

	}
	
	public void delete(String isbn) {
		for(int i=0; i<books.size(); i++) {
			if(books.get(i).isbn.equals(isbn)) {
				books.remove(i);
			}
		}
	}
	
	public List<Book> searchByTitle(String title) {
		List<Book> list = new LinkedList<>();
		for (int i = 0; i < books.size(); i++) {
			if (books.get(i).title.equals(title)) {
				list.add(books.get(i));
			}
		}
		
		return list;
	}
	
	public List<Book> searchByAuthor(String author) {
		List<Book> list = new LinkedList<>();
		for (int i = 0; i < books.size(); i++) {
			if (books.get(i).author.equals(author)) {
				list.add(books.get(i));
			}
		}
		
		return list;
	}
	
	public List<Book> searchByPrice(int price) {
		List<Book> list = new LinkedList<>();
		for (int i = 0; i < books.size(); i++) {
			if (books.get(i).price.equals(price)) {
				list.add(books.get(i));
			}
		}
		
		return list;
	}

}
