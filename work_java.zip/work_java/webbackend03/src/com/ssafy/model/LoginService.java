package com.ssafy.model;

public class LoginService {
	private static LoginService service= new LoginService();
	
	public static LoginService getService() {
		return service;
	}
	
	private LoginService() {}
	
	public boolean login(String id, String pass) {
		return id.equals("ssafy") && pass.equals("1111");
	}
}
