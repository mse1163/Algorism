package com.ssafy.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.model.LoginService;

/**
 * Servlet implementation class CookieLoginServlet
 */
@WebServlet("/login/cookieLogin")
public class CookieLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 입력검증
		String id = request.getParameter("id");
		String pw = request.getParameter("pass");
		
		// 모델 연동
		boolean result = LoginService.getService().login(id, pw);
		
		// 쿠키 처리 및 페이지 이동
		String target = "loginFail.jsp";
		if(result) {
			Cookie loginCookie = new Cookie("loginId", id);
			loginCookie.setMaxAge(60*60*24*30);
			response.addCookie(loginCookie);
			
			HttpSession session = request.getSession();
			session.setAttribute("loginId", id);
			target = "loginSuccess.jsp";
		}
		
		RequestDispatcher disp = request.getRequestDispatcher(target);
		disp.forward(request, response);
	}

}
