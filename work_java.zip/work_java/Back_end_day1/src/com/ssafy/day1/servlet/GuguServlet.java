package com.ssafy.day1.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TimeTableServlet
 */
//@WebServlet(value="/gugu")
//@WebServlet(urlPatterns="/gugu")
//@WebServlet(value= {"/gugu"})
@WebServlet("/biz/gugu")
public class GuguServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 응답 내용 작성
		String strDan = request.getParameter("dan");
		
		int dan = strDan != null? Integer.parseInt(strDan): 5;

		TimeTable tt = new TimeTable();
		String result = tt.getTimeTable(dan);
		
		
		// 작성된 HTML을 응답을 통해서 전송!!
		response.getWriter().append(result);
	}

//	private String getTimesTable(int dan) {
//		String data = "time table for"+ dan;
//		
//		return null;
//	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
