package com.ssafy.day1.servlet;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

/**
 * Servlet Filter implementation class PerformanceFilter
 */
@WebFilter("/*")
public class PerformanceFilter implements Filter {

    /**
     * Default constructor. 
     */
    public PerformanceFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		long start = System.nanoTime();
		System.out.println("아직 서블릿 호출 전.......필요한 필터의 동작 작성");
		// pass the request along the filter chain
		// 다음 필터 또는 서블릿 호출
		chain.doFilter(request, response);
		System.out.println("서블릿 응답 후");
		long end = System.nanoTime();
		HttpServletRequest hreq= (HttpServletRequest)request;
		System.out.println("서블릿명: "+hreq.getServletPath()+" : "+hreq.getMethod()+", 동작시간: "+(end-start));
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
