package com.ssafy.day1.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html; charset=utf-8");
		// name과 pass 파라미터를 받은 후 콘솔에 출력한다.
		String name = request.getParameter("name");
		String pass = request.getParameter("pass");
		
		System.out.println("do get: "+name+" : "+ pass);
		// 만약 name이 홍길동, password가 1234면 홍길동님 반갑습니다. 그렇지 않으면 다시 로그인 하세요 라고 화면에 출력.
		String msg = "<h1>다시 로그인하세요.</h1>";
		if(name.equals("홍길동") && pass.equals("1234")) {
			msg = "<h1>홍길동님 반갑습니다.</h1>";
		}
		
		response.getWriter().append(msg);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// encoding 처리.
//		request.setCharacterEncoding("utf-8");
//		response.setContentType("text/html; charset=utf-8");
		
		//추가적인 속성 전달
		request.setAttribute("attr", "추가적인 객체를 저장할 수 있어요.");
		System.out.println(request.getAttribute("attr"));
		
		// name과 pass 파라미터를 받은 후 콘솔에 출력한다.
		String name = request.getParameter("name");
		String pass = request.getParameter("pass");
		
		System.out.println("do post: "+name+" : "+ pass);
		// 만약 name이 홍길동, password가 1234면 홍길동님 반갑습니다. 그렇지 않으면 다시 로그인 하세요 라고 화면에 출력.
		String msg = "<h1>다시 로그인하세요.</h1>";
		if(name.equals("홍길동") && pass.equals("1234")) {
			msg = "<h1>홍길동님 반갑습니다.</h1>";
		}
		
		response.getWriter().append(msg);
	}

}
