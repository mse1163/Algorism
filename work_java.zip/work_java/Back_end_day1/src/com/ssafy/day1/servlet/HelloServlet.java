package com.ssafy.day1.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloServlet
 */
@WebServlet(
		description = "처음이야.", 
		urlPatterns = { 
				"/HelloServlet/gugu", 
				"/hi"	// Servlet에서 '/'는 context root
		})
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	public void init() throws ServletException {
		System.out.println("서블릿 초기화 처리..");
		super.init();
		// context에 설정된 파라미터 확인하기
		ServletContext ctx = this.getServletContext();
		System.out.println(ctx.getInitParameter("configfile"));
		
		//application level에서 파일에 대한 접근 지원
		InputStream input = ctx.getResourceAsStream(ctx.getInitParameter("configfile"));
		Properties props = new Properties();
		try {
			props.load(input);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(props);
	}
	
	@Override
	public void destroy() {
		System.out.println("서블릿 정리 작업");
		super.destroy();
	}
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("service 호출"+req.getMethod());
		super.service(req, resp);
	}
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("서블릿 호출됨");
		response.getWriter().append("<html><body><h1> Get 호출 Served at:</h1></body></html> ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Post 호출 Served at: ").append(request.getContextPath());
	}
	
	

}
