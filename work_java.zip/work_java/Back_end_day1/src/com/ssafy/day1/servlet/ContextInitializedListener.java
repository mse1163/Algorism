package com.ssafy.day1.servlet;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class ContextInnerListener
 *
 */
@WebListener
public class ContextInitializedListener implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public ContextInitializedListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
    	System.out.println("애플리케이션이 종료됩니다. - initialized에서 초기화한 자원의 원상 복구");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
    	System.out.println("애플리케이션 초기화 됩니다. - 개별 서블릿이 공유할 어려운 무거운 작업은 여기서 해주세요.");
    
    }
	
}
