import java.util.LinkedList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

class Point{
	String name, material, image;

	public Point(String name, String material, String image) {
		super();
		this.name = name;
		this.material = material;
		this.image = image;
	}

	@Override
	public String toString() {
		return "Point [name=" + name + ", material=" + material + ", image=" + image + "]";
	}
	
}

public class XmlSaxParser extends DefaultHandler {
	// SAXParserFactory
	private SAXParserFactory parserFactory;

	// SAXParser
	private SAXParser parser;

	// xml 파일명
	private String fileName;

	private String startTagName;

	private String endTagName;

	// String buffer
	private StringBuffer buffer = new StringBuffer();

	// 추출값 이름, 성분, 이미지
	private String name;
	private String material;
	private String image;

	public XmlSaxParser() {
	}

	public XmlSaxParser(String fileName) {

		parserFactory = SAXParserFactory.newInstance();

		try {
			parser = parserFactory.newSAXParser();
		} catch (ParserConfigurationException | SAXException e) {
			System.out.println("Exception >> " + e.toString());
			e.printStackTrace();
		}

		this.fileName = fileName;
	}

	public void startDocument() {
		System.out.println("start document!!");
	}

	public void endDocument() {
		System.out.println("end document!!");
	}

	public void startElement(String url, String n, String elementName, Attributes attrs) throws SAXException {
		startTagName = elementName;

		buffer.setLength(0);
	}

	private List<Point> list = new LinkedList<>();

	public void characters(char[] str, int start, int len) throws SAXException {
		buffer.append(str, start, len);

		if (this.startTagName.equals("name")) {
			this.name = buffer.toString().trim();
		}

		if (this.startTagName.equals("material")) {
			this.material = buffer.toString().trim();
		}

		if (this.startTagName.equals("image")) {
			this.image = buffer.toString().trim();
		}

//		list.add(name+" "+ material+ " "+ image);
	}

	public void endElement(String url, String localName, String n) {
		endTagName = n;
		if(n.equals("food")) {
//			System.out.println("name=" + this.getName());
//			System.out.println("material=" + this.getMaterial());
//			System.out.println("image=" + this.getImage());
			list.add(new Point(name, material, image));
		}
	}

	public void parse() {
		try {
			parser.parse(fileName, this);

		} catch (Exception e) {
			System.out.println("XMLSAXParser Exception " + e.toString());
		}
		
	}

	public List<Point> getList() {
		return list;
	}

	public void setList(List<Point> list) {
		this.list = list;
	}

	public String getName() {
		return name;
	}

	public String getMaterial() {
		return material;
	}

	public String getImage() {
		return image;
	}

}
