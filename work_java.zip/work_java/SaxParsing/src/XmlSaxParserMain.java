import java.util.List;

public class XmlSaxParserMain {

	public static void main(String[] args) {
		XmlSaxParser parser = new XmlSaxParser("res/foodInfo.xml");
		
		parser.parse();

		for(Point s: parser.getList())
			System.out.println(s);
		
	}
}
