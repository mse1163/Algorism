package com.ssafy.model;

public class CalcService {
	// 모델은 singleton design을 적용한다.
	// 모든 클라이언트에게 따로 서비스할 필요는 없다!!
	private CalcService() {
		
	}
	private static CalcService service = new CalcService();
	
	public static CalcService getService() {
		return service;
	}
	
	public int addResult(int num1, int num2) {
		return num1+num2;
	}

}
