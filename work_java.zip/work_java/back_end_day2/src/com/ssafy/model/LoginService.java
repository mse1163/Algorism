package com.ssafy.model;

import java.util.Properties;

public class LoginService {
	
	private LoginService() {}
	
	private static LoginService service = new LoginService();
	public static LoginService getService() {
		return service;
	}
	
	private Properties props = new Properties(); // id,pass, name 저장
	
	public Properties getProps() {
		return props;
	}
	
	public void setProps(Properties props) {
		this.props = props;
	}
	
	public String login(String id, String pass) {
		if(id.equals(props.getProperty("id")) && pass.equals(props.getProperty("pass"))) {
			return props.getProperty("name");
		}
		else {
			return null;
		}
	}
	
}
