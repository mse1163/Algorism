package com.ssafy.listener;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.ssafy.model.LoginService;

/**
 * Application Lifecycle Listener implementation class ContextListener
 *
 */
@WebListener
public class ContextListener implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public ContextListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce)  { 
         // TODO Auto-generated method stub
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce)  { 
         // 애플리케이션이 실행 될 때 - 무거운 작업 처리 
    	 //userinf.properties에서 정보 취득 --> Service에 전달
    	ServletContext ctx = sce.getServletContext();
    	// 초기화 파라미터 접근
    	String infoFile = ctx.getInitParameter("userinfo");
    	// 파일 자원에 대한 접근
    	InputStream input = ctx.getResourceAsStream(infoFile);
    	// 파일 내용을 Properties로 변환
    	LoginService service = LoginService.getService();
    	try {
			service.getProps().load(input);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	
    }
	
}
