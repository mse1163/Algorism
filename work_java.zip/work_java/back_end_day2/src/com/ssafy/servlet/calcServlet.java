package com.ssafy.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.model.CalcService;

/**
 * Servlet implementation class calcServlet
 */
@WebServlet("/calc/calc")
public class calcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// servlet의 controller로써의 역한
		// 1. 요청 파라미터 검증
		
		String num1 = request.getParameter("num1");
		String num2 = request.getParameter("num2");
		
		if(!num1.equals("") && !num2.equals("")) {
			// 2. Model에게 데이터에 대한 처리 요청 
			int n1 = Integer.parseInt(num1);
			int n2 = Integer.parseInt(num2);
			int result = CalcService.getService().addResult(n1, n2);
			//3. Model에게서 전달받은 데이터를 뷰에 전달해서 화면에 보여주기
			request.setAttribute("result" , result);
			//3-1 forward로 전송
			RequestDispatcher dispatcher = request.getRequestDispatcher("calcResult.jsp");
			dispatcher.forward(request, response);
			
//			response.sendRedirect("calResult.jsp");
		}
		else {
			response.sendRedirect("calcpage.html");
		}
		
		
	}


}
