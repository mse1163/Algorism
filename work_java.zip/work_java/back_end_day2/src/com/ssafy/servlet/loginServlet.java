package com.ssafy.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ssafy.model.LoginService;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1. 파라미터 검증
		String id = request.getParameter("id");
		String pass = request.getParameter("pass");
		
		// 2. model에 처리 위임
		String result= LoginService.getService().login(id, pass);
		// 3. 결과를 화면에 전달
		
		if(result!=null) {
			request.setAttribute("result" , result);
			RequestDispatcher dispatcher = request.getRequestDispatcher("calc/loginresult.jsp");
			dispatcher.forward(request, response);
		}
		else {
			response.sendRedirect("calc/loginform.jsp");
		}
		
		
		
	}
}
