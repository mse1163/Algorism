package com.ssafy.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Response;


/**
 * Servlet implementation class ErrorTestServlet
 */
@WebServlet("/errortest")
public class ErrorTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String param = request.getParameter("type");
		if(param==null) {
			// 강제 오류 코드 발생시키기
			response.sendError(Response.SC_NOT_FOUND);
		}
		else if(param.equals("class")) {
			try {
				Class.forName("Hello");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				throw new ServletException(e);
			}
		}else if(param.equals("null")) {
			Object obj = null;
			obj.toString();			// NullPointerException >> RuntimeException
		}
		
	}


}
