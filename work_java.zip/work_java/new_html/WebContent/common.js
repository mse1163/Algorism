/**
 * 
 */
	var data = 10;
	console.log(typeof data, data);
	data ="Hello";
	console.log(typeof data, data);
	console.log(alert);
	
	var alert = "Hello";
	console.log(alert);

	var myvar;
	console.log("undefined : 아직 초기화  되지 않은 상태", myvar);
	/*
	var result = prompt("9 * 9 = ?" , "값 입력");
	console.log(result);
	
	var check = confirm("입력한 값이 " + result +  "입니까?");
	console.log(check);
	*/
	
//	일치연산자 : 정말 같냐?
	var f = false;
	var num = 0;
	console.log("형 변환 후 비교 : ==", f==num,"형변환 없이 비교 ===", f===num);
	
	var a = false;
	let b = false;
	
	console.log(a==b, a===b);
	
// '', false, 0, null, undefined
// boolean 필요한 곳에서 '', false, 0, null, undefined 경우 false 나머지 true;
	
	let ab ='Hello';
	console.log(ab);
	if(ab){
		
		console.log("참");
	}
	else{
		console.log("거짓");
		
	}
	
	
	
	
	