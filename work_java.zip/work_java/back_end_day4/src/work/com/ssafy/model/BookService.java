package work.com.ssafy.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookService {
	private BookService() {
	}

	private static BookService service = new BookService();

	public static BookService getService() {
		return service;
	}
	
	// Book을 저장할 List
	Map<String, Book> books = new HashMap<>();
	
	// isbn은 중복하지 않도록
	public boolean add(Book book) {
		if(books.get(book.getIsbn())==null) {
			books.put(book.getIsbn(), book);
			return true;
		}else {
			return false;
		}
	}
	
	// 전체 도서 목록 리턴
	public Collection<Book> search(){
		return books.values();
	}
	
	// isbn에 해당하는 도서 정보 리턴
	public Book searchByIsbn(String isbn) {
		return books.get(isbn);
	}

	// isbn에 해당하는 도서 정보 삭제
	public void delete(String isbn) {
		books.remove(isbn);
	}
	
	// 상황에 따른 검색 결과 리턴
	public List<Book> bookSearch(String by, String keyword){
		
		List<Book> searched = new ArrayList<>();
		Collection<Book> allBooks = books.values();
		for(Book book: allBooks) {
			if(by.equals("title")) {
				if(book.getTitle().contains(keyword)) {
					searched.add(book);
				}
			}else if(by.equals("publisher")) {
				if(book.getPublisher().equals(keyword)) {
					searched.add(book);
				}
			}else if(by.equals("price")) {
				if(book.getPrice().equals(keyword)) {
					searched.add(book);
				}
			}
		}
		return searched;
	}
	

	public Book makeBook(String title, String isbn, String category, String country, String date, String publisher, String author, String price, String unit, String desc) {
		return new Book(title, isbn, category, country, date, publisher, author, price, unit, desc);
	}
}
