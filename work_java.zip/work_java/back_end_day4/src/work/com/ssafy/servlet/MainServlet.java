package work.com.ssafy.servlet;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Collection;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import work.com.ssafy.model.Book;
import work.com.ssafy.model.BookService;
import work.com.ssafy.model.LoginService;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("*.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	BookService service = BookService.getService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if (action.equals("login")) {
			doLogin(request, response);
		} else if (action.equals("list")) {
			doBookList(request, response);
		} else if (action.equals("search")) {
			doSearch(request, response);
		} else if (action.equals("detail")) {
			doDetail(request, response);
		} else if (action.equals("delete")) {
			doDeleteBook(request, response);
		} else if (action.equals("searchajax")) {
			doBookListAjax(request, response);
		} else if (action.equals("logout")) {
			doLogout(request, response);
		} else if (action.equals("last")) {
			doLastBook(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if (action.equals("add")) {
			doAddBook(request, response);
		}
	}

	public void doDeleteBook(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String isbn = request.getParameter("isbn");
		service.delete(isbn);

		RequestDispatcher disp = request.getRequestDispatcher("DeleteResult.jsp");
		disp.forward(request, response);
	}

	public void doDetail(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String isbn = request.getParameter("isbn");

		Book book = service.searchByIsbn(isbn);

		request.setAttribute("book", book);

		RequestDispatcher disp = request.getRequestDispatcher("BookView.jsp");
		disp.forward(request, response);
	}

	public void doAddBook(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String isbn = request.getParameter("isbn1") + "-" + request.getParameter("isbn2") + "-"
				+ request.getParameter("isbn3");
		String title = request.getParameter("title");
		String cat = request.getParameter("category");
		String country = request.getParameter("country");
		String pubDate = request.getParameter("date");

		String publisher = request.getParameter("publisher");

		String author = request.getParameter("author");
		String price = request.getParameter("price");
		String unit = request.getParameter("unit");
		String desc = request.getParameter("desc");

		// model 연동
		Book book = service.makeBook(title, isbn, cat, country, pubDate, publisher, author, price, unit, desc);
		boolean result = service.add(book);

		// 도서 정보를 쿠키에 등록 --> 7일간 저장
		Cookie bookCookie = new Cookie("bookInfo", 
				URLEncoder.encode(book.toString(), "utf-8"));
		bookCookie.setMaxAge(60 * 60 * 24 * 7);
		response.addCookie(bookCookie);

		// ajax로 호출할꺼니까 데이터만 전달!
		response.getWriter().append("" + result);
	}

	// login 처리
	public void doLogin(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String id = request.getParameter("id");
		String pass = request.getParameter("pass");

		// 로그인 가능 여부를 모델에게 확인
		boolean result = LoginService.getService().login(id, pass);
		// 페이지 분기 처리
		if (result) {
			Cookie loginCookie = new Cookie("loginId", id);
			loginCookie.setMaxAge(60 * 60 * 24 * 30);// 한달동안 저장
			response.addCookie(loginCookie);
			
			HttpSession session = request.getSession();
			session.setAttribute("loginId", id);
			
			RequestDispatcher disp = request.getRequestDispatcher("LoginSuccess.jsp");
			disp.forward(request, response);
		} else {
			request.setAttribute("msg", "아이디 또는 패스워드가 다릅니다.");
			RequestDispatcher disp = request.getRequestDispatcher("Error.jsp");
			disp.forward(request, response);
		}
	}

	// 도서 목록 보기 처리
	public void doBookList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Collection<Book> books = service.search();
		request.setAttribute("books", books);

		RequestDispatcher disp = request.getRequestDispatcher("BookList.jsp");
		disp.forward(request, response);
	}

	// 도서 목록 보기 처리
	public void doBookListAjax(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String by = request.getParameter("by");
		String keyword = request.getParameter("keyword");
		System.out.println(by + " : " + keyword);

		List<Book> searched = service.bookSearch(by, keyword);
		Gson gson = new Gson();
		String json = gson.toJson(searched);
		response.getWriter().append(json);
	}

	public void doSearch(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String by = request.getParameter("by");
		String keyword = request.getParameter("keyword");
		System.out.println(by + " : " + keyword);

		List<Book> searched = service.bookSearch(by, keyword);
		request.setAttribute("books", searched);
		RequestDispatcher disp = request.getRequestDispatcher("BookList.jsp");
		disp.forward(request, response);
	}

	public void doLogout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Cookie cookie = new Cookie("loginId", "some");
		cookie.setMaxAge(0);
		response.addCookie(cookie);

		HttpSession session = request.getSession();
		session.invalidate();
		response.sendRedirect(request.getContextPath() + "/work/Login.html");
	}

	public void doLastBook(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Cookie[] cookies = request.getCookies();
		String info = null;
		for (Cookie cookie : cookies) {
			if (cookie.getName().equals("bookInfo")) {
				info = URLDecoder.decode(cookie.getValue(), "utf-8");
				break;
			}
		}
		System.out.println(info);
		if (info != null) {
			StringTokenizer tokens = new StringTokenizer(info, ",");
			Book book = new Book();
			while (tokens.hasMoreTokens()) {// 개별 토큰: title=" + title 
				StringTokenizer sub = new StringTokenizer(tokens.nextToken(), "=");
				String key = sub.nextToken().trim();
				String value = sub.nextToken().trim();
				System.out.println(key+" : "+value);
				if (key.equals("isbn")) {
					book.setIsbn(value);
				} else if (key.equals("author")) {
					book.setAuthor(value);
				} else if (key.equals("publisher")) {
					book.setPublisher(value);
				}
			}
			request.setAttribute("book", book);

			RequestDispatcher disp = request.getRequestDispatcher("BookView.jsp");
			disp.forward(request, response);
		} else {// 책에 대한 정보가 없었다면..
			response.sendRedirect("RecentAddBookFail.jsp");
		}
	}
}
