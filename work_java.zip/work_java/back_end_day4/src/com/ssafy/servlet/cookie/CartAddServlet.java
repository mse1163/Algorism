package com.ssafy.servlet.cookie;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CartAddServlet
 */
@WebServlet("/cart/addCart")
public class CartAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		// 파라미터로 전달된 product를  cart에 담는다.
		String product = request.getParameter("product");
		// 내가 쓰던 카트가 있나?
		HttpSession session = request.getSession();
		Object obj = session.getAttribute("cart");
		List<String> cart = null;
		if(obj==null) {	// 아직 카트가 생성되지 않은 경우
			cart = new ArrayList<>();
			session.setAttribute("cart", cart);
		}else {			// 기존에 카트가 있는 경우
			cart = (ArrayList)obj;
		}
		// 카트에 상품 담기
		cart.add(product);
		// 상품 정보 반환
		response.getWriter().append(cart.toString());
		
		
	}

}
