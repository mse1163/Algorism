package com.ssafy.servlet.cookie;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.model.LoginService;

/**
 * Servlet implementation class CookieLoginServlet
 */
@WebServlet("/cookie/cookieLogin")
public class CookieLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 입력 검증
		String id = request.getParameter("id");
		String pass = request.getParameter("pass");
		// 모델 연동
		boolean result = LoginService.getService().login(id, pass);
		// 쿠키 처리 및 페이지 이동
		String target = "loginFail.jsp";
		if(result) {
			Cookie loginCookie = new Cookie("loginId", id);
			loginCookie.setMaxAge(60 * 60);
			response.addCookie(loginCookie);	// to browser
			
			//request.setAttribute("loginId", id);// to next page
			HttpSession session = request.getSession();
			session.setAttribute("loginId", id);// to session
			target = "main.jsp";
		}
		RequestDispatcher disp = request.getRequestDispatcher(target);
		disp.forward(request, response);
	}

}
