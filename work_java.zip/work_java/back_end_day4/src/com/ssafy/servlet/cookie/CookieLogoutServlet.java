package com.ssafy.servlet.cookie;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CookieLogoutServlet
 */
@WebServlet("/cookie/logout")
public class CookieLogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 쿠키 삭제(유효기간 = 0)
		Cookie loginCookie = new Cookie("loginId", "some");
		loginCookie.setMaxAge(0);
		response.addCookie(loginCookie);
		// 사용자 세션 만료
		HttpSession session = request.getSession();
		session.invalidate();
		
		// 새로운 페이지(loginForm.jsp)로 이동
		response.sendRedirect("loginform.jsp");
	}
}





