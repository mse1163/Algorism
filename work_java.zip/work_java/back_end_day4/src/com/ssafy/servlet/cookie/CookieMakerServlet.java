package com.ssafy.servlet.cookie;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookieMakerServlet
 */
@WebServlet("/cookiemaker")
public class CookieMakerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 유효기간에 따라 3개의 쿠키를 생성하고 response를 통해 내려보내기.
		Cookie cookie1 = new Cookie("id", "hong");
		cookie1.setMaxAge(60 * 2);
		response.addCookie(cookie1);
		
		Cookie cookie2 = new Cookie("name", "홍길동");
		cookie2.setMaxAge(-1);
		response.addCookie(cookie2);
		
		Cookie cookie3 = new Cookie("age", "30");// 문자열만 전달 가능
		cookie3.setMaxAge(0);
		response.addCookie(cookie3);
		

		response.getWriter().append("<html><body><a href='cookieconsumer'>consumer</a></body></html>");
	}

}
