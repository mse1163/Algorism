package com.ssafy.servlet.cookie;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CheckCookieServlet
 */
@WebServlet("/cookie/checkCookie")
public class CheckCookieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1. 입력값 검증(Cookie)
		String target = "loginform.jsp";
		Cookie [] cookies = request.getCookies();
		if(cookies!=null) {
			for(Cookie c: cookies) {
				System.out.println(c.getName()+" : "+c.getValue());
				// 로그인 사용자의 쿠키를  loginId라고 한다면..
				if(c.getName().equals("loginId")) {// 로그인한 경험이 있는 사용자
					target = "main.jsp";
					// 로그인 사용자의 정보를 세션에서 관리
					HttpSession session = request.getSession();
					session.setAttribute("loginId", c.getValue());
					break;
				}
			}
		}
		// 2. cookie에 따른 페이지 연결
		RequestDispatcher disp = request.getRequestDispatcher(target);
		disp.forward(request, response);
		
	}

}
