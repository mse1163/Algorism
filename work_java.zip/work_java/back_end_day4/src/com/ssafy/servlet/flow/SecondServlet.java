package com.ssafy.servlet.flow;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class SecondServlet
 */
@WebServlet("/flow/SecondServlet")
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("second servlet 확인");
		System.out.println("request: "+request.getAttribute("reqAttr"));
		HttpSession session = request.getSession();
		System.out.println("session: "+session.getAttribute("sesAttr"));
		ServletContext ctx = request.getServletContext();
		System.out.println("application: "+ctx.getAttribute("ctxAttr"));
		
		RequestDispatcher disp = request.getRequestDispatcher("second.jsp");
		disp.forward(request, response);
	}

}
