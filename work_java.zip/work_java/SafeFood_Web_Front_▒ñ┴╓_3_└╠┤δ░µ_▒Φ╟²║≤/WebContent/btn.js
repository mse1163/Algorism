
function btnone() {	

	 
		$("#modaltitle").empty();
		$("#modal-insert").empty();
		$("#myChart").empty();
		$("#modaltitle").append(totalname[0]+"("+totalmaker[0]+")");
		
		//modal-insert
		var li ="";
		console.log(arr[0].length);
		for(var i=0; i<arr[0].length; i++){
			li += "<li>"+arr[0][i]+"</li>\n";
		}
		
		$("#modal-insert").append(
				"<div class ='row'>"+
				"<div class='testimonial-item mx-auto mb-3 col-lg-4' >"+
				"<img class='img-fluid rounded-circle mb-3' src="+totalimage[0]+" alt=''>"+
				"<a class='btn btn-primary' href='#'>추가하기</a>"+
				"<a class='btn btn-primary' href='#'>찜하기</a>"+
				"</div>" +
				
				"<h4>영양 정보</h4>"+
				"<p>"+tmpmet[0]+"</p>"+
				"</div>"
				);
			 
		
	/* 여기는 거시기 ~*/
	let cal=0;
	let carb =0;
	let prot =0;
	let fat=0;
	let sweet=0;
	let sault=0;
	let idx=0;
	$.ajax({
	 type: "GET",
	 url: "foodNut.xml",
	 dataType: "xml",
	 success : function(xml) {
		 console.log("가져오기성공");
		 $(xml).find("item").each(function(){
			 if(idx==0){
			cal = $(this).find("NUTR_CONT1").text();
			carb = $(this).find("NUTR_CONT2").text();
			prot =$(this).find("NUTR_CONT3").text();;
			fat=$(this).find("NUTR_CONT4").text();;
			sweet=$(this).find("NUTR_CONT5").text();;
			sault=$(this).find("NUTR_CONT6").text();;
			
			
			graph(cal,carb, prot, fat, sweet, sault);
				
			 idx++;
			 }
		 
			 })//success
			
		 
	 }
			})//ajax
			 
			
			 
 
	
	function graph(cal, carb, prot, fat, sweet, sault) {
		var ctx = document.getElementById("myChart").getContext('2d');
		var myChart = new Chart(ctx, {
	    type: 'pie',
	    data: {
	        labels: ["칼로리","탄수화물", "단백질", "지방", "설탕", "소금"],
	        datasets: [{
	            label: '# of Votes',
	            data: [cal, carb, prot, fat, sweet, sault],
	            backgroundColor: [
	                'rgba(255, 99, 132, 0.2)',
	                'rgba(54, 162, 235, 0.2)',
	                'rgba(255, 206, 86, 0.2)',
	                'rgba(75, 192, 192, 0.2)',
	                'rgba(153, 102, 255, 0.2)',
	                'rgba(255, 159, 64, 0.2)'
	            ],
	            borderColor: [
	                'rgba(255,99,132,1)',
	                'rgba(54, 162, 235, 1)',
	                'rgba(255, 206, 86, 1)',
	                'rgba(75, 192, 192, 1)',
	                'rgba(153, 102, 255, 1)',
	                'rgba(255, 159, 64, 1)'
	            ],
	            borderWidth: 1
	        }]
	    },
	    options: {
	        scales: {
	            yAxes: [{
	                ticks: {
	                    beginAtZero:true
	                }
	            }]
	        }
	    }
	});
		
	$("#ChartInfo").append("<field>칼로리 : " + cal+"</field>\n" + "탄수화물 : " +carb +"\n"+ "단백질 : "+ prot +"\n" + "지방 : " + fat + "\n" + "당류 : " +  sweet +"\n" + 
							"소금 : " + sault);
	}
}

