

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.model.LoginService;
import com.ssafy.model.Product;
import com.ssafy.model.ProductService;


/**
 * Servlet implementation class SubmitServlet
 */
@WebServlet("*.do")
public class SubmitServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	ProductService service = ProductService.getService();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if (action.equals("login")) {
			doLogin(request, response);
		}
		else if(action.equals("logout")) {
			doLogout(request, response);
		}
		else if(action.equals("product")) {
			doproduct(request, response);
		}
		else if(action.equals("list")) {
			doProductList(request, response);
		}
		
	}
	
	public void doproduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String num = request.getParameter("num");
		String name = request.getParameter("name");
		String price = request.getParameter("price");
		String desc = request.getParameter("desc");
		
		HttpSession session = request.getSession();
		Object obj = session.getAttribute("product");

		service.add(new Product(num, name, price, desc));
		
//		Cookie proCookie = new Cookie("productInfo", URLEncoder.encode(p.toString(), "utf-8"));
//		proCookie.setMaxAge(60 * 60 * 24 * 7);
//		response.addCookie(proCookie);

		RequestDispatcher disp = request.getRequestDispatcher("MainResult.jsp");
		disp.forward(request, response);
	}
	
	public void doLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 입력검증
		String id = request.getParameter("id");
		String pw = request.getParameter("pass");
		
		// 모델 연동
		boolean result = LoginService.getService().login(id, pw);
		
		// 쿠키 처리 및 페이지 이동
		String target = "loginFail.jsp";
		if(result) {
			Cookie loginCookie = new Cookie("loginId", id);
			loginCookie.setMaxAge(60*60*24*30);
			response.addCookie(loginCookie);
			
			HttpSession session = request.getSession();
			session.setAttribute("loginId", id);
			target = "loginSuccess.jsp";
		}
		
		RequestDispatcher disp = request.getRequestDispatcher(target);
		disp.forward(request, response);
	}
	
	public void doLogout(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Cookie cookie = new Cookie("loginId", "some");
		cookie.setMaxAge(0);
		response.addCookie(cookie);

		HttpSession session = request.getSession();
		session.invalidate();
		response.sendRedirect(request.getContextPath() + "/login/loginform.jsp");
	}
	
	// 도서 목록 보기 처리
		public void doProductList(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			Collection<Product> products = service.search();
			request.setAttribute("products", products);

			RequestDispatcher disp = request.getRequestDispatcher("productList.jsp");
			disp.forward(request, response);
		}
	
	public void doLastProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Cookie[] cookies = request.getCookies();
		String info = null;
		for (Cookie cookie : cookies) {
			if (cookie.getName().equals("bookInfo")) {
				info = URLDecoder.decode(cookie.getValue(), "utf-8");
				break;
			}
		}
		System.out.println(info);
		if (info != null) {
			StringTokenizer tokens = new StringTokenizer(info, ",");
			Product product = new Product();
			while (tokens.hasMoreTokens()) {// 개별 토큰: title=" + title 
				StringTokenizer sub = new StringTokenizer(tokens.nextToken(), "=");
				String key = sub.nextToken().trim();
				String value = sub.nextToken().trim();
				System.out.println(key+" : "+value);
				if (key.equals("num")) {
					product.setNum(value);
				} else if (key.equals("price")) {
					product.setPrice(value);
				} else if (key.equals("desc")) {
					product.setDesc(value);
				}
			}
			request.setAttribute("product", product);

			RequestDispatcher disp = request.getRequestDispatcher("productView.jsp");
			disp.forward(request, response);
		}
	}
}
