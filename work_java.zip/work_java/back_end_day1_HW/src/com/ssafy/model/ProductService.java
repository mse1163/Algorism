package com.ssafy.model;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;



public class ProductService {

	private ProductService() {}
	
	private static ProductService service = new ProductService();
	
	public static ProductService getService() {
		return service;
	}
	
	List<Product> products = new LinkedList<>();
	
	// isbn은 중복하지 않도록
	public void add(Product product) {
		products.add(product);
	}
	
	// 전체 도서 목록 리턴
	public List<Product> search(){
		return products;
	}
	
	public Product make(String num, String name, String price, String desc) {
		return new Product(num, name, price, desc);
	}
}
