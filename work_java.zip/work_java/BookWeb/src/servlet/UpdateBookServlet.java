package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.BookDao;
import vo.BookVO;

/**
 * Servlet implementation class UpdateBookServlet
 */
@WebServlet("/updateBook.do")
public class UpdateBookServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		
		int id = Integer.parseInt(req.getParameter("id"));
		System.out.println(id);
		
		BookVO book = BookDao.getInstance().selectOne(id);
		req.setAttribute("book", book);
		req.setAttribute("id", id);
		req.getRequestDispatcher("/jsp/updateBook.jsp").forward(req, res);
		
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		req.setCharacterEncoding("UTF-8");
		
		int id = Integer.parseInt(req.getParameter("id"));
		String title = req.getParameter("title");
		String publisher = req.getParameter("publisher");
		String year = req.getParameter("year");
		int price = Integer.parseInt(req.getParameter("price"));
		
//		System.out.println(id+" "+title+" "+publisher+" "+year+" "+price);
		
		BookVO vo = new BookVO();
		vo.setBookid(id);
		vo.setTitle(title);
		vo.setPublisher(publisher);
		vo.setYear(year);
		vo.setPrice(price);
		
		BookDao.getInstance().updateBook(vo);
		res.sendRedirect("bookList.do");
		
	
	}

}
