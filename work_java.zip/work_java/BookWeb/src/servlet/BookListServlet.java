package servlet;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.BookDao;
import vo.BookVO;

/**
 * Servlet implementation class BookListServlet
 */
@WebServlet("/bookList.do")
public class BookListServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// BookDao를 이용해서 모든 책의 리스트를 조회한 수 attribute에 실어서
		req.setAttribute("bookList", BookDao.getInstance().selectAll());
		
		// bookList.jsp로 포워드
		req.getRequestDispatcher("/jsp/bookList.jsp").forward(req, res);
	}

}

