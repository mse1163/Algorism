package servlet;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/whattime.do")
public class whatTimeServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
//		super.doGet(req, resp);
		
		req.setAttribute("time", new Date());
		req.getRequestDispatcher("WEB-INF/jsp/whattime.jsp").forward(req, resp);
	}
		
}
