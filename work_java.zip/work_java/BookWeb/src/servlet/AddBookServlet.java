package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.BookDao;
import vo.BookVO;

/**
 * Servlet implementation class AddBook
 */

@WebServlet("/addBook.do")
public class AddBookServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		// addBook.jsp로 포워드
		req.getRequestDispatcher("/jsp/addBook.jsp").forward(req, res);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// 파라미터로 넘어온 책정보를 BookVO로 객체 만들어서 BookDao에게 추가해달라고 전달 후
		// bookList.do 리다이레션
		req.setCharacterEncoding("UTF-8");
		BookVO vo = new BookVO();
		vo.setTitle(req.getParameter("title"));
		vo.setPublisher(req.getParameter("publisher"));
		vo.setYear(req.getParameter("year"));
		vo.setPrice(Integer.parseInt(req.getParameter("price")));
		
		BookDao.getInstance().insertBook(vo);
		resp.sendRedirect("bookList.do");
		
	}
	
	

}
