package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import vo.BookVO;
 
/**
 * day02 디비의 book테이블에 대해서 데이터를 삽입 삭제 수정 조회 하는 기능
 * 
 * @author admin
 */
public class BookDao {
    private Connection conn;
 
    private BookDao() {
        try {
        	// 웹 어플리케이션에서는 클래스네임 적재 생략 불가!!
        	Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection(
                    "jdbc:mysql://127.0.0.1/day02?characterEncoding=UTF-8&serverTimezone=UTC", "root", "1234");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
 
    private static BookDao instance;
 
    public static BookDao getInstance() {
        if (instance == null)
            instance = new BookDao();
        return instance;
    }
 
    /**
     * 책 한권의 정보를 데이터베이스에 삽입하는 기능
     * 
     * @param book
     *            책 한권에 대한 정보가 BookVO타입으로 전달되어짐
     * @return 쿼리문 수행에 의해 영향을 받은 레코드의 수를 리턴
     */
    public int insertBook(BookVO book) {
        String sql = "INSERT INTO books VALUES(0,?,?,?,?)";
        PreparedStatement pstmt = null;
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, book.getTitle());
            pstmt.setString(2, book.getPublisher());
            pstmt.setString(3, book.getYear());
            pstmt.setInt(4, book.getPrice());
            return pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return -1;
    }
 
    public int updateBook(BookVO book) {
        String sql = "UPDATE books SET title = ?, publisher = ?, year = ?, price = ? WHERE book_id = ?";
        PreparedStatement pstmt = null;
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, book.getTitle());
            pstmt.setString(2, book.getPublisher());
            pstmt.setString(3, book.getYear());
            pstmt.setInt(4, book.getPrice());
            pstmt.setInt(5, book.getBookid());
            return pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return -1;
    }
 
    public int deleteBook(int bookid) {
        String sql = "DELETE FROM books WHERE book_id = ?";
        PreparedStatement pstmt = null;
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, bookid);
            return pstmt.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return -1;
    }
 
    public List<BookVO> selectAll() {
        // conn을 이용해 select문을 날리고 조회된 모든 책의 정보를 리스트로 만들어 리턴하시오.
        List<BookVO> list = new ArrayList<>();
        String sql = "SELECT * FROM books";
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while(rs.next()) {
                BookVO book = new BookVO();
                book.setBookid(rs.getInt(1));
                book.setTitle(rs.getString(2));
                book.setPublisher(rs.getString("publisher"));
                book.setYear(rs.getString("year"));
                book.setPrice(rs.getInt("price"));
                list.add(book);
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if(rs != null)
                    rs.close();
                if(pstmt != null )
                    pstmt.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        return list;
    }
    public BookVO selectOne(int bookid) {
        String sql = "SELECT * FROM books WHERE book_id = ?";
        BookVO book = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, bookid);
            rs = pstmt.executeQuery();
            if(rs.next()) {
                book = new BookVO();
                book.setBookid(rs.getInt(1));
                book.setTitle(rs.getString(2));
                book.setPublisher(rs.getString("publisher"));
                book.setYear(rs.getString("year"));
                book.setPrice(rs.getInt("price"));
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                if(rs != null)
                    rs.close();
                if(pstmt != null )
                    pstmt.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
         
        return book;
    }
 
}
