package com.ssafy.servlet.flow;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class FirstServlet
 */
@WebServlet("/firstServlet")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 정보를 각각의 영역에 저장한다.
		request.setAttribute("reqAttr", "reqAttr");
		HttpSession session = request.getSession();
		session.setAttribute("sesAttr", "sesAttr");
		ServletContext ctx = request.getServletContext();
		ctx.setAttribute("ctxAttr", "ctxAttr");
		
		String param = request.getParameter("type");
		String target = "flow/first.jsp";
		
		if(param.equals("forward")) {
			RequestDispatcher disp = request.getRequestDispatcher(target);
			disp.forward(request, response);
		}
		else if(param.equals("redirect")) {
			response.sendRedirect(target);
		}
	}

}
