package cookie;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CookiemakerServlet
 */
@WebServlet("/CookiemakerServlet")
public class CookiemakerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 유효기간에 따라 3개의 쿠키를 생성하고 response를 통해 내려보내기.
		Cookie cookie1 = new Cookie("id", "hong");
		cookie1.setMaxAge(60*2);	// 2분간 유효한 쿠키
		response.addCookie(cookie1);	// 클라이언트에 전송
		
		Cookie cookie2 = new Cookie("name", "홍길동");
		cookie2.setMaxAge(-1);
		response.addCookie(cookie2);
		
		Cookie cookie3 = new Cookie("age", "30");
		cookie3.setMaxAge(0);
		response.addCookie(cookie3);
		
		//response.getWriter().append("check cookie plz...");
		response.getWriter().append("<html><body><a href='cookieconsumer'>consumer</a></body></html>");
	}

}
