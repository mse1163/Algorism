package cookie;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.LoginService;

/**
 * Servlet implementation class login
 */
@WebServlet("/cookie/cookieLogin")
public class CookieLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 입력 검증
		String id = request.getParameter("id");
		String password = request.getParameter("pass");
		
		// 모델 연동
		boolean result = LoginService.getService().login(id, password);
		// 쿠키 처리 및 페이지 이동
		String target = "loginFail.jsp";
		if(result) {
			Cookie loginCookie = new Cookie("loginId", id);
			loginCookie.setMaxAge(60*1);
			response.addCookie(loginCookie);	// to browser
			//request.setAttribute("loginId", id); // to next page
			HttpSession session = request.getSession();
			// session 시간 변경 - 초단위
			session.setMaxInactiveInterval(3*60);
			
			session.setAttribute("loginId", id);	// to session
			target = "main.jsp";
		}
		
		
		
		RequestDispatcher disp = request.getRequestDispatcher(target);
		disp.forward(request, response);
		
	}

}
