package Sax;

public class XmlSaxParserMain {

	public static void main(String[] args) {
		XmlSaxParser parser = new XmlSaxParser("WebContent/res/foodInfo.xml");
		
		parser.parse();

		for(Foodsax s: parser.getList())
			System.out.println(s);
		
	}
}
