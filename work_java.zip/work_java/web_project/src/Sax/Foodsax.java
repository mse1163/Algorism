package Sax;

public class Foodsax{
	private String name, material, image;

	public Foodsax(String name, String material, String image) {
		super();
		this.name = name;
		this.material = material;
		this.image = image;
	}

	@Override
	public String toString() {
		return "Point [name=" + name + ", material=" + material + ", image=" + image + "]";
	}

	
}
