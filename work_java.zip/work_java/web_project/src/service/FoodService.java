package service;

import java.util.List;

import vo.Food;
import vo.FoodPageBean;

public interface FoodService {
	
	public List<Food> searchAll(FoodPageBean bean);
	public Food search(int code);
	public List<Food> searchBest();
	public List<Food> searchBestIndex();	
	
}
