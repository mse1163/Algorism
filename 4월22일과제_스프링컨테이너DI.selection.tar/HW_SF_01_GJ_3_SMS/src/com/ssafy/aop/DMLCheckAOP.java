package com.ssafy.aop;

public class DMLCheckAOP {

}
