package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;


@Component
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repo;
	
	
	
	public ProductServiceImpl() {
		
	}

	public ProductServiceImpl(ProductRepo repo) {
		this.repo = repo;
	}
	
	@Override
	public ProductRepo getRepo() {
		return repo;
	}

	@Override
	public List<Product> selectAll() {
		return repo.sellectAll();
	}

	@Override
	public int insert(Product product) {
		// TODO Auto-generated method stub
		return repo.insert(product);
	}

	@Override
	public int update(Product product) {
		// TODO Auto-generated method stub
		return repo.update(product);
	}

	@Override
	public int delete(String id) {
		// TODO Auto-generated method stub
		return repo.delete(id);
	}

}
