package com.ssafy.model.repository;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.ssafy.model.dto.Product;

@Component
public class ProductRepoImpl implements ProductRepo {
	
	Logger logger = LoggerFactory.getLogger(ProductRepoImpl.class);
	
	@Override
	public List<Product> sellectAll() {
		logger.debug("selectAll()");
		return null;
	}

	@Override
	public Product select(String id) {
		logger.debug("select : id : {}",id);
		return null;
	}

	@Override
	public int insert(Product product) {
		logger.debug("insert : {}",product);
		return 0;
	}

	@Override
	public int update(Product product) {
		logger.debug("update : {}",product);
		return 0;
	}

	@Override
	public int delete(String id) {
		logger.debug("delete : id : {}",id);
		return 0;
	}

}
