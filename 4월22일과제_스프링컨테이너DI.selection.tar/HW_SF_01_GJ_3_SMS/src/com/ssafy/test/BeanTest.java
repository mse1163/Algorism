package com.ssafy.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.ssafy.config.ApplicationConfig;
import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;
import com.ssafy.model.repository.ProductRepoImpl;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

public class BeanTest {

	public static void main(String[] args) {
		ApplicationContext ctx = 
				new AnnotationConfigApplicationContext(ApplicationConfig.class);
		ProductService service = ctx.getBean(ProductService.class);
		ProductRepo repo = ctx.getBean(ProductRepo.class);
		
		Product product = new Product();
		product.setId("상품아이디");
		product.setName("상품명");
		product.setPrice(1000);
		product.setDescription("좋은상품");
		
		service.delete(product.getId());
		service.update(product);
		service.insert(product);
		
	}

}
