package com.ssafy.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.ssafy.model.repository.ProductRepo;
import com.ssafy.model.repository.ProductRepoImpl;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

@Configuration

//@ComponentScan(basePackageClasses= {ProductService.class , ProductRepo.class})
public class ApplicationConfig {

	@Bean
	public ProductRepo productRepo() {
		return new ProductRepoImpl();
	}
	@Bean
	public ProductService productService(ProductRepo repo) {
		ProductService service = new ProductServiceImpl(repo);
		return service;
	}
}
