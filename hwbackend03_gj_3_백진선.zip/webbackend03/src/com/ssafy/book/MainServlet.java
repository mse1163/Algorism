package com.ssafy.book;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/main")
public class MainServlet extends HttpServlet {
	BookMgr bm = BookMgr.getService();
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String key = request.getParameter("list");
		String value = request.getParameter("search");
		String kind = request.getParameter("kind");

		//System.out.println(kind);
		if(kind.equals("listsearch")) {
			List<Book> b = bm.search();
			request.setAttribute("list", b);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("BookList.jsp");
			dispatcher.forward(request, response);
		}
		else if(kind.equals("search")) {
			if(key.equals("title")) {
				List<Book> b = bm.searchByTitle(value);
				request.setAttribute("list", b);
			}
			else if(value.equals("num")) {
				List<Book> b = bm.searchByIsbn(value);
				request.setAttribute("list", b);
			}
			else if(value.equals("author")) {
				List<Book> b = bm.searchByAuthor(value);	
				request.setAttribute("list", b);
			}
			else {
				List<Book> b = bm.search();
				request.setAttribute("list", b);
			}
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("BookList.jsp");
			dispatcher.forward(request, response);
		}
		else if(kind.equals("delete")) {
			String de = request.getParameter("key");
			bm.delete(de);
			List<Book> b = bm.search();
			request.setAttribute("list", b);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("delete.jsp");
			dispatcher.forward(request, response);
		}
		
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html; charset=utf-8");


		String isbn = request.getParameter("isbn1")+"-"+request.getParameter("isbn2")+"-"+request.getParameter("isbn3");
		String title = request.getParameter("title");
		String catalogue = request.getParameter("category");
		String nation = request.getParameter("country");
		String publishDate = request.getParameter("date");
		String publisher = request.getParameter("publisher");
		String author = request.getParameter("author");
		String price = request.getParameter("price") + request.getParameter("unit");
		String description = request.getParameter("desc");

		if(publisher.equals("multi")) {
			publisher = "멀티캠퍼스";
		}
		else if(publisher.equals("hanbit")) {
			publisher = "한빛미디어";
		}
		else if(publisher.equals("kame")) {
			publisher="가매출판사";
		}

		bm.add(new Book(isbn, title, catalogue, nation, publishDate, publisher, author, price, description));

		response.sendRedirect("Result.jsp");



	}

}
